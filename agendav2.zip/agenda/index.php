<?php
// Arquivo: index.php
require 'includes/auth.php';
require 'includes/db.php';

// --- BUSCAR DADOS REAIS ---

// 1. Ocorrências Abertas (Suporte/Pendências)
$oco_abertas = $pdo->query("SELECT COUNT(*) FROM ocorrencias WHERE status = 'Aberto'")->fetchColumn();

// 2. Ocorrências Em Andamento
$oco_andamento = $pdo->query("SELECT COUNT(*) FROM ocorrencias WHERE status = 'Em Andamento'")->fetchColumn();

// 3. Vendas (Pedidos) neste mês atual
$mes_atual = date('m');
$vendas_mes = $pdo->query("SELECT SUM(valor_total) FROM pedidos_orcamentos WHERE tipo = 'pedido' AND status != 'Cancelado' AND MONTH(data_emissao) = '$mes_atual'")->fetchColumn();

// 4. Agenda Hoje (Eventos manuais + Retornos de suporte)
$hoje = date('Y-m-d');
$agenda_hoje = $pdo->query("SELECT COUNT(*) FROM agenda_eventos WHERE DATE(inicio) = '$hoje'")->fetchColumn();
$retornos_hoje = $pdo->query("SELECT COUNT(*) FROM ocorrencias WHERE DATE(data_retorno) = '$hoje' AND status != 'Concluido'")->fetchColumn();
$total_agenda = $agenda_hoje + $retornos_hoje;

// 5. Últimas 5 Ocorrências (Para lista rápida)
$ultimas_oco = $pdo->query("SELECT o.*, c.nome_fantasia FROM ocorrencias o JOIN clientes c ON o.cliente_id = c.id ORDER BY o.id DESC LIMIT 5")->fetchAll();

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Suindara v2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css?v=2" rel="stylesheet">
</head>
<body>

    <?php include 'includes/sidebar.php'; ?>

    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="text-white">Visão Geral</h2>
            <a href="ocorrencias.php?view=form" class="btn btn-info fw-bold" style="background: var(--neon-blue); border:none; color:black;">+ Nova Ocorrência</a>
        </div>

        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card-custom border-start border-4 border-danger">
                    <h5 class="text-muted">Chamados Abertos</h5>
                    <h2 class="text-white mt-2"><?= $oco_abertas ?></h2>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card-custom border-start border-4 border-warning">
                    <h5 class="text-muted">Em Atendimento</h5>
                    <h2 class="text-white mt-2"><?= $oco_andamento ?></h2>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card-custom border-start border-4 border-success">
                    <h5 class="text-muted">Vendas (Mês Atual)</h5>
                    <h2 class="text-white mt-2">R$ <?= number_format($vendas_mes ?: 0, 2, ',', '.') ?></h2>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card-custom border-start border-4 border-primary">
                    <h5 class="text-muted">Agenda Hoje</h5>
                    <h2 class="text-white mt-2"><?= $total_agenda ?></h2>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8">
                <div class="card card-custom p-0">
                    <div class="p-3 border-bottom border-secondary">
                        <h5 class="m-0 text-white">Últimas Atualizações</h5>
                    </div>
                    <table class="table table-dark table-hover mb-0">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Cliente</th>
                                <th>Assunto</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($ultimas_oco as $u): 
                                $badge = match($u['status']) { 'Aberto'=>'bg-danger', 'Concluido'=>'bg-success', default=>'bg-warning text-dark' };
                            ?>
                            <tr>
                                <td>#<?= $u['id'] ?></td>
                                <td><?= $u['nome_fantasia'] ?></td>
                                <td><?= $u['assunto'] ?></td>
                                <td><span class="badge <?= $badge ?>"><?= $u['status'] ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(empty($ultimas_oco)) echo "<tr><td colspan='4' class='text-center text-muted p-3'>Nenhuma atividade recente.</td></tr>"; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card card-custom p-3">
                    <h5 class="text-info mb-3">Acesso Rápido</h5>
                    <div class="d-grid gap-2">
                        <a href="orcamentos.php?view=form" class="btn btn-outline-light text-start">📄 Novo Orçamento</a>
                        <a href="clientes.php?view=form&acao=novo" class="btn btn-outline-light text-start">👥 Cadastrar Cliente</a>
                        <a href="agenda.php" class="btn btn-outline-light text-start">📅 Ver Agenda Completa</a>
                        <a href="kanban.php" class="btn btn-outline-light text-start">🚀 Fluxo de Vendas</a>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>