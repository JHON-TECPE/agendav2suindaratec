<?php
// Arquivo: imprimir_orcamento.php
require 'includes/auth.php';
require 'includes/db.php';

if (!isset($_GET['id'])) die("ID não informado");

$id = $_GET['id'];
$orc = $pdo->query("SELECT o.*, c.*, u.nome as vendedor_nome 
                    FROM pedidos_orcamentos o 
                    JOIN clientes c ON o.cliente_id = c.id 
                    JOIN usuarios u ON o.vendedor_id = u.id 
                    WHERE o.id = $id")->fetch();

$itens = $pdo->query("SELECT i.*, p.nome, p.unidade 
                      FROM pedidos_itens i 
                      JOIN produtos p ON i.produto_id = p.id 
                      WHERE i.pedido_id = $id")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Orçamento #<?= $orc['id'] ?></title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; color: #000; background: #fff; margin: 0; padding: 20px; }
        .header { display: flex; justify-content: space-between; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px; }
        .header-left { width: 60%; }
        .header-right { width: 40%; text-align: right; }
        h1 { margin: 0; font-size: 24px; color: #333; }
        
        .box-info { border: 1px solid #ccc; padding: 10px; margin-bottom: 10px; background: #f9f9f9; }
        .row { display: flex; margin-bottom: 5px; }
        .col { flex: 1; }
        .label { font-weight: bold; margin-right: 5px; }

        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th { background: #eee; border: 1px solid #ccc; padding: 8px; text-align: left; }
        td { border: 1px solid #ccc; padding: 8px; }
        .text-center { text-align: center; }
        .text-end { text-align: right; }

        .total-box { margin-top: 20px; text-align: right; font-size: 16px; font-weight: bold; }
        .footer { margin-top: 50px; text-align: center; border-top: 1px solid #ccc; padding-top: 10px; font-size: 10px; color: #777; }

        @media print {
            .no-print { display: none; }
            body { padding: 0; }
        }
    </style>
</head>
<body>

    <div class="no-print" style="margin-bottom: 20px; text-align: right;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #007bff; color: white; border: none; cursor: pointer;">🖨️ IMPRIMIR / SALVAR PDF</button>
        <button onclick="window.close()" style="padding: 10px 20px; background: #666; color: white; border: none; cursor: pointer;">FECHAR</button>
    </div>

    <div class="header">
        <div class="header-left">
            <h1>SUINDARA TEC</h1>
            <p><strong>CNPJ:</strong> 70.301.361/0001-44<br>
            <strong>End:</strong> Avenida Portugal, 1330 - Universitário<br>
            <strong>Contato:</strong> (81) 99440-8620 | johnny.santos@suindaratec.com.br</p>
        </div>
        <div class="header-right">
            <h2>ORÇAMENTO Nº <?= str_pad($orc['id'], 6, '0', STR_PAD_LEFT) ?></h2>
            <p>Data: <?= date('d/m/Y', strtotime($orc['data_emissao'])) ?></p>
            <p>Vendedor: <?= $orc['vendedor_nome'] ?></p>
        </div>
    </div>

    <div class="box-info">
        <div class="row">
            <div class="col"><span class="label">Cliente:</span> <?= $orc['razao_social'] ?></div>
            <div class="col"><span class="label">CPF/CNPJ:</span> <?= $orc['cnpj_cpf'] ?></div>
        </div>
        <div class="row">
            <div class="col"><span class="label">Endereço:</span> <?= $orc['endereco_completo'] ?>, <?= $orc['bairro'] ?> - <?= $orc['cidade'] ?>/<?= $orc['uf'] ?></div>
        </div>
        <div class="row">
            <div class="col"><span class="label">Responsável PO:</span> <?= $orc['po_responsavel'] ?></div>
            <div class="col"><span class="label">Telefone:</span> (Ver cadastro)</div>
        </div>
    </div>

    <div class="box-info" style="border: 1px dashed #999;">
        <div class="row">
            <div class="col"><span class="label">Forma Pagamento:</span> <?= $orc['forma_pagamento'] ?></div>
            <div class="col"><span class="label">Validade:</span> <?= $orc['validade_dias'] ?> dias</div>
        </div>
        <div class="row">
            <div class="col"><span class="label">Observações:</span> <?= $orc['observacoes'] ?></div>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th width="5%">#</th>
                <th>Descrição / Produto / Serviço</th>
                <th width="10%" class="text-center">Unid.</th>
                <th width="10%" class="text-center">Qtd.</th>
                <th width="15%" class="text-end">Vlr. Unit.</th>
                <th width="15%" class="text-end">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $count=1; foreach($itens as $item): ?>
            <tr>
                <td><?= $count++ ?></td>
                <td><?= $item['nome'] ?></td>
                <td class="text-center"><?= $item['unidade'] ?></td>
                <td class="text-center"><?= number_format($item['quantidade'], 2, ',', '.') ?></td>
                <td class="text-end">R$ <?= number_format($item['valor_unitario'], 2, ',', '.') ?></td>
                <td class="text-end">R$ <?= number_format($item['valor_total'], 2, ',', '.') ?></td>
            </tr>
            <?php endforeach; ?>
            
            <tr><td colspan="6" style="border:none; height: 10px;"></td></tr>
        </tbody>
    </table>

    <div class="total-box">
        <p>TOTAL GERAL: R$ <?= number_format($orc['valor_total'], 2, ',', '.') ?></p>
    </div>

    <div class="footer">
        <p>Este orçamento é um documento preliminar e sujeita-se à confirmação de estoque e valores no ato do fechamento.</p>
        <p>Sistema Suindara TEC - Gerado em <?= date('d/m/Y H:i') ?></p>
    </div>

</body>
</html>