<?php
// Arquivo: clientes.php
require 'includes/auth.php';
require 'includes/db.php';

$view = isset($_GET['view']) ? $_GET['view'] : 'lista';
$msg = '';
$erro = '';

// --- LÓGICA DE SALVAMENTO ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $pdo->beginTransaction();

        // A. SALVAR CLIENTE (DADOS GERAIS)
        if (isset($_POST['salvar_geral'])) {
            $dados_cliente = [
                $_POST['tipo_pessoa'], $_POST['cnpj_cpf'], $_POST['razao_social'], $_POST['nome_fantasia'],
                $_POST['cep'], $_POST['endereco'], $_POST['bairro'], $_POST['cidade'], $_POST['uf'],
                $_POST['horario'], $_POST['segmento'], $_POST['po_resp'], $_POST['escopo']
            ];

            if ($_POST['acao'] == 'novo') {
                $sql = "INSERT INTO clientes (tipo_pessoa, cnpj_cpf, razao_social, nome_fantasia, cep, endereco_completo, bairro, cidade, uf, horario_funcionamento, segmento, po_responsavel, escopo_desc) 
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute($dados_cliente);
                $cliente_id = $pdo->lastInsertId();
                $msg = "Cliente cadastrado com sucesso! Agora preencha as outras abas.";
                // Redireciona para edição para liberar as outras abas
                header("Location: clientes.php?view=form&id=$cliente_id&msg=criado");
                exit;
            } else {
                $cliente_id = $_POST['id'];
                $sql = "UPDATE clientes SET tipo_pessoa=?, cnpj_cpf=?, razao_social=?, nome_fantasia=?, cep=?, endereco_completo=?, bairro=?, cidade=?, uf=?, horario_funcionamento=?, segmento=?, po_responsavel=?, escopo_desc=? WHERE id=?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute(array_merge($dados_cliente, [$cliente_id]));
                
                // Salvar Fiscal
                $pdo->prepare("DELETE FROM clientes_fiscais WHERE cliente_id = ?")->execute([$cliente_id]);
                $sql_fiscal = "INSERT INTO clientes_fiscais (cliente_id, regime_tributario, cfop_padrao, icms_interno, icms_externo, pis_aliq, cofins_aliq, simples_aliq, usa_reforma, ibs_cbs_class, aliq_cbs, aliq_ibs_mun, aliq_ibs_uf) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $pdo->prepare($sql_fiscal)->execute([
                    $cliente_id, $_POST['regime'], $_POST['cfop_padrao'] ?? '',
                    $_POST['icms_int'] ?? 0, $_POST['icms_ext'] ?? 0, $_POST['pis'] ?? 0, $_POST['cofins'] ?? 0, $_POST['simples'] ?? 0,
                    isset($_POST['usa_reforma']) ? 1 : 0, 
                    $_POST['class_ibs'] ?? '', $_POST['aliq_cbs'] ?? 0, $_POST['aliq_ibs_mun'] ?? 0, $_POST['aliq_ibs_uf'] ?? 0
                ]);

                // Salvar Acesso Remoto
                $pdo->prepare("DELETE FROM clientes_acessos WHERE cliente_id = ?")->execute([$cliente_id]);
                if (!empty($_POST['soft_remoto'])) {
                    $pdo->prepare("INSERT INTO clientes_acessos (cliente_id, software, usuario_remoto, senha_remoto, codigo_acesso, computador_nome) VALUES (?, ?, ?, ?, ?, ?)")
                        ->execute([$cliente_id, $_POST['soft_remoto'], $_POST['user_remoto'], $_POST['pass_remoto'], $_POST['id_remoto'], $_POST['pc_nome']]);
                }
                
                $msg = "Dados atualizados com sucesso!";
            }
        }

        // B. SALVAR CERTIFICADO (UPLOAD)
        if (isset($_POST['upload_certificado'])) {
            $cliente_id = $_POST['id'];
            $senha_cert = $_POST['senha_certificado'];
            
            if (isset($_FILES['arquivo_cert']) && $_FILES['arquivo_cert']['error'] == 0) {
                $ext = pathinfo($_FILES['arquivo_cert']['name'], PATHINFO_EXTENSION);
                $novo_nome = "cert_" . $cliente_id . "_" . time() . "." . $ext;
                $destino = "uploads/certificados/" . $novo_nome;
                
                if (move_uploaded_file($_FILES['arquivo_cert']['tmp_name'], $destino)) {
                    $pdo->prepare("INSERT INTO clientes_certificados (cliente_id, arquivo_nome, caminho_arquivo, senha_winrar) VALUES (?, ?, ?, ?)")
                        ->execute([$cliente_id, $_FILES['arquivo_cert']['name'], $destino, $senha_cert]);
                    $msg = "Certificado anexado com sucesso!";
                } else {
                    $erro = "Falha ao mover arquivo. Verifique as permissões da pasta uploads.";
                }
            }
        }

        // C. SALVAR PÓS-VENDA
        if (isset($_POST['salvar_posvenda'])) {
            $cliente_id = $_POST['id'];
            $texto = $_POST['obs_posvenda'];
            if(!empty($texto)) {
                $pdo->prepare("INSERT INTO clientes_pos_venda (cliente_id, usuario_id, texto) VALUES (?, ?, ?)")
                    ->execute([$cliente_id, $_SESSION['user_id'], $texto]);
                $msg = "Histórico registrado!";
            }
        }

        $pdo->commit();

    } catch (Exception $e) {
        $pdo->rollBack();
        $erro = "Erro: " . $e->getMessage();
    }
}

// --- RECUPERAÇÃO DE DADOS ---
$cliente = null;
$fiscal = null;
$acesso = null;
$certificados = [];
$pos_vendas = [];
$ocorrencias = [];
$produtos = [];

if ($view == 'form' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $cliente = $pdo->query("SELECT * FROM clientes WHERE id = $id")->fetch();
    $fiscal = $pdo->query("SELECT * FROM clientes_fiscais WHERE cliente_id = $id")->fetch();
    $acesso = $pdo->query("SELECT * FROM clientes_acessos WHERE cliente_id = $id")->fetch();
    $certificados = $pdo->query("SELECT * FROM clientes_certificados WHERE cliente_id = $id ORDER BY id DESC")->fetchAll();
    
    // Pós Venda com nome do usuário
    $pos_vendas = $pdo->query("SELECT pv.*, u.nome as usuario FROM clientes_pos_venda pv JOIN usuarios u ON pv.usuario_id = u.id WHERE pv.cliente_id = $id ORDER BY pv.data_registro DESC")->fetchAll();
    
    // Ocorrências deste cliente
    $ocorrencias = $pdo->query("SELECT * FROM ocorrencias WHERE cliente_id = $id ORDER BY id DESC")->fetchAll();

    // Produtos adquiridos (Mockup ou query real se tabela pedidos existir e tiver dados)
    // $produtos = $pdo->query("SELECT p.nome, pi.quantidade, pi.valor_unitario, po.data_emissao FROM pedidos_itens pi JOIN produtos p ON pi.produto_id = p.id JOIN pedidos_orcamentos po ON pi.pedido_id = po.id WHERE po.cliente_id = $id AND po.tipo = 'pedido'")->fetchAll();
}

if(isset($_GET['msg']) && $_GET['msg']=='criado') $msg = "Cliente criado! Continue preenchendo as abas.";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Clientes - Suindara v2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <style>
        .nav-tabs .nav-link { color: #aaa; border: 1px solid transparent; }
        .nav-tabs .nav-link:hover { color: var(--neon-blue); }
        .nav-tabs .nav-link.active { background-color: var(--card-bg); color: var(--neon-blue); border-color: #444; border-bottom-color: var(--card-bg); font-weight: bold; }
        .tab-content { border: 1px solid #444; border-top: none; padding: 25px; background: var(--card-bg); border-radius: 0 0 8px 8px; min-height: 400px; }
        .table-dark th { color: var(--neon-blue); }
    </style>
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        
        <?php if($view == 'lista'): ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="text-white">Gestão de Clientes</h3>
                <a href="?view=form&acao=novo" class="btn btn-info fw-bold" style="background: var(--neon-blue); border:none; color:black;">+ Novo Cliente</a>
            </div>
            
            <?php if($msg) echo "<div class='alert alert-success'>$msg</div>"; ?>

            <div class="card card-custom p-0 table-responsive">
                <table class="table table-dark table-hover mb-0">
                    <thead class="bg-secondary">
                        <tr>
                            <th class="ps-4">Empresa</th>
                            <th>CNPJ/CPF</th>
                            <th>Cidade</th>
                            <th>Contato</th>
                            <th class="text-end pe-4">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $lista = $pdo->query("SELECT * FROM clientes ORDER BY id DESC LIMIT 50")->fetchAll();
                        foreach($lista as $c): 
                        ?>
                        <tr>
                            <td class="ps-4">
                                <strong class="text-info"><?= $c['nome_fantasia'] ?: $c['razao_social'] ?></strong>
                            </td>
                            <td><?= $c['cnpj_cpf'] ?></td>
                            <td><?= $c['cidade'] ?>/<?= $c['uf'] ?></td>
                            <td><?= $c['po_responsavel'] ?></td>
                            <td class="text-end pe-4">
                                <a href="?view=form&id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-info">Abrir Ficha</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php else: ?>
            <div class="d-flex justify-content-between mb-3 align-items-center">
                <div>
                    <h3 class="text-white m-0"><?= $cliente ? $cliente['nome_fantasia'] : 'Novo Cliente' ?></h3>
                    <small class="text-muted"><?= $cliente ? $cliente['razao_social'] : 'Preencha os dados iniciais' ?></small>
                </div>
                <a href="?view=lista" class="btn btn-outline-secondary">Voltar para Lista</a>
            </div>

            <?php if($msg) echo "<div class='alert alert-success'>$msg</div>"; ?>
            <?php if($erro) echo "<div class='alert alert-danger'>$erro</div>"; ?>

            <ul class="nav nav-tabs" id="clientTab" role="tablist">
                <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#geral">📋 Geral</button></li>
                
                <?php if($cliente): // Só mostra as outras abas se o cliente já existir ?>
                    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#fiscal">⚖️ Fiscal</button></li>
                    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#remoto">💻 Acesso Remoto</button></li>
                    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#certificados">🔐 Certificado Digital</button></li>
                    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#produtos">📦 Produtos/Serviços</button></li>
                    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#posvenda">💬 Pós-Venda</button></li>
                    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#ocorrencias">🔔 Ocorrências</button></li>
                <?php else: ?>
                    <li class="nav-item"><button class="nav-link disabled">Salva o Geral Primeiro ➡️</button></li>
                <?php endif; ?>
            </ul>

            <div class="tab-content">
                
                <div class="tab-pane fade show active" id="geral">
                    <form method="POST">
                        <input type="hidden" name="salvar_geral" value="1">
                        <input type="hidden" name="acao" value="<?= $cliente ? 'editar' : 'novo' ?>">
                        <?php if($cliente): ?><input type="hidden" name="id" value="<?= $cliente['id'] ?>"><?php endif; ?>

                        <div class="row g-3">
                            <div class="col-md-3">
                                <label>Tipo</label>
                                <select name="tipo_pessoa" class="form-select">
                                    <option value="J" <?= ($cliente['tipo_pessoa']??'')=='J'?'selected':'' ?>>Pessoa Jurídica</option>
                                    <option value="F" <?= ($cliente['tipo_pessoa']??'')=='F'?'selected':'' ?>>Pessoa Física</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label>CNPJ / CPF</label>
                                <div class="input-group">
                                    <input type="text" name="cnpj_cpf" id="cnpj" class="form-control" value="<?= $cliente['cnpj_cpf']??'' ?>">
                                    <button type="button" class="btn btn-outline-info" onclick="buscarCNPJ()">🔍 Buscar CNPJ</button>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <label>Razão Social</label>
                                <input type="text" name="razao_social" id="razao" class="form-control" required value="<?= $cliente['razao_social']??'' ?>">
                            </div>
                            <div class="col-md-6">
                                <label>Nome Fantasia</label>
                                <input type="text" name="nome_fantasia" id="fantasia" class="form-control" value="<?= $cliente['nome_fantasia']??'' ?>">
                            </div>
                            <div class="col-md-6">
                                <label>Segmento</label>
                                <input type="text" name="segmento" class="form-control" value="<?= $cliente['segmento']??'' ?>">
                            </div>
                            
                            <div class="col-12"><hr class="border-secondary"></div>

                            <div class="col-md-2">
                                <label>CEP</label>
                                <input type="text" name="cep" id="cep" class="form-control" onblur="buscarCEP()" value="<?= $cliente['cep']??'' ?>">
                            </div>
                            <div class="col-md-5">
                                <label>Endereço</label>
                                <input type="text" name="endereco" id="endereco" class="form-control" value="<?= $cliente['endereco_completo']??'' ?>">
                            </div>
                            <div class="col-md-3">
                                <label>Bairro</label>
                                <input type="text" name="bairro" id="bairro" class="form-control" value="<?= $cliente['bairro']??'' ?>">
                            </div>
                            <div class="col-md-2">
                                <label>Cidade / UF</label>
                                <div class="d-flex gap-1">
                                    <input type="text" name="cidade" id="cidade" class="form-control" value="<?= $cliente['cidade']??'' ?>">
                                    <input type="text" name="uf" id="uf" class="form-control" style="width:60px;" value="<?= $cliente['uf']??'' ?>">
                                </div>
                            </div>

                            <div class="col-12"><hr class="border-secondary"></div>

                            <div class="col-md-4">
                                <label>Horário Funcionamento</label>
                                <input type="text" name="horario" class="form-control" value="<?= $cliente['horario_funcionamento']??'' ?>">
                            </div>
                            <div class="col-md-4">
                                <label>PO Responsável</label>
                                <input type="text" name="po_resp" class="form-control" value="<?= $cliente['po_responsavel']??'' ?>">
                            </div>
                            <div class="col-md-12">
                                <label>Escopo do Projeto</label>
                                <textarea name="escopo" rows="3" class="form-control"><?= $cliente['escopo_desc']??'' ?></textarea>
                            </div>
                        </div>

                        <div class="d-none">
                            </div>
                        
                        <div class="d-flex justify-content-end mt-4">
                            <button type="submit" class="btn btn-success fw-bold px-5">SALVAR DADOS GERAIS</button>
                        </div>
                </div>

                <div class="tab-pane fade" id="fiscal">
                        <div class="row">
                            <div class="col-md-6 border-end border-secondary">
                                <h5 class="text-info mb-3">Regime Tradicional</h5>
                                <div class="mb-3">
                                    <label>Regime Tributário</label>
                                    <select name="regime" class="form-select">
                                        <option value="Simples" <?= ($fiscal['regime_tributario']??'')=='Simples'?'selected':'' ?>>Simples Nacional</option>
                                        <option value="Normal" <?= ($fiscal['regime_tributario']??'')=='Normal'?'selected':'' ?>>Normal / Lucro</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label>CFOP Padrão</label>
                                    <input type="text" name="cfop_padrao" class="form-control" value="<?= $fiscal['cfop_padrao']??'' ?>">
                                </div>
                                <div class="row g-2">
                                    <div class="col-6"><label>ICMS Int %</label><input type="text" name="icms_int" class="form-control" value="<?= $fiscal['icms_interno']??'' ?>"></div>
                                    <div class="col-6"><label>ICMS Ext %</label><input type="text" name="icms_ext" class="form-control" value="<?= $fiscal['icms_externo']??'' ?>"></div>
                                    <div class="col-6"><label>PIS %</label><input type="text" name="pis" class="form-control" value="<?= $fiscal['pis_aliq']??'' ?>"></div>
                                    <div class="col-6"><label>COFINS %</label><input type="text" name="cofins" class="form-control" value="<?= $fiscal['cofins_aliq']??'' ?>"></div>
                                </div>
                            </div>
                            <div class="col-md-6 ps-4">
                                <h5 class="text-warning mb-3">Reforma Tributária</h5>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" name="usa_reforma" id="checkRef" <?= ($fiscal['usa_reforma']??0)==1?'checked':'' ?>>
                                    <label class="form-check-label" for="checkRef">Ativar Reforma Tributária</label>
                                </div>
                                <div class="mb-3">
                                    <label>Classificação IBS/CBS</label>
                                    <input type="text" name="class_ibs" class="form-control" value="<?= $fiscal['ibs_cbs_class']??'' ?>">
                                </div>
                                <div class="row g-2">
                                    <div class="col-4"><label>Aliq. CBS</label><input type="text" name="aliq_cbs" class="form-control" value="<?= $fiscal['aliq_cbs']??'' ?>"></div>
                                    <div class="col-4"><label>IBS Mun.</label><input type="text" name="aliq_ibs_mun" class="form-control" value="<?= $fiscal['aliq_ibs_mun']??'' ?>"></div>
                                    <div class="col-4"><label>IBS UF</label><input type="text" name="aliq_ibs_uf" class="form-control" value="<?= $fiscal['aliq_ibs_uf']??'' ?>"></div>
                                </div>
                            </div>
                        </div>
                        <div class="mt-4 text-end"><button class="btn btn-success">Salvar Fiscal</button></div>
                </div>

                <div class="tab-pane fade" id="remoto">
                    <div class="row g-3">
                        <div class="col-md-4"><label>Software</label><input type="text" name="soft_remoto" class="form-control" placeholder="AnyDesk / TeamViewer" value="<?= $acesso['software']??'' ?>"></div>
                        <div class="col-md-4"><label>ID / Acesso</label><input type="text" name="id_remoto" class="form-control" value="<?= $acesso['codigo_acesso']??'' ?>"></div>
                        <div class="col-md-4"><label>Nome PC</label><input type="text" name="pc_nome" class="form-control" value="<?= $acesso['computador_nome']??'' ?>"></div>
                        <div class="col-md-6"><label>Usuário Remoto</label><input type="text" name="user_remoto" class="form-control" value="<?= $acesso['usuario_remoto']??'' ?>"></div>
                        <div class="col-md-6"><label>Senha Remota</label><input type="text" name="pass_remoto" class="form-control" value="<?= $acesso['senha_remoto']??'' ?>"></div>
                    </div>
                    <div class="mt-4 text-end"><button class="btn btn-success">Salvar Acesso Remoto</button></div>
                </div>
                
                </form> <div class="tab-pane fade" id="certificados">
                    <form method="POST" enctype="multipart/form-data" class="row g-3 align-items-end mb-4 border-bottom border-secondary pb-4">
                        <input type="hidden" name="upload_certificado" value="1">
                        <input type="hidden" name="id" value="<?= $cliente['id'] ?>">
                        
                        <div class="col-md-5">
                            <label>Arquivo (WinRAR/ZIP)</label>
                            <input type="file" name="arquivo_cert" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label>Senha do Arquivo (Se houver)</label>
                            <input type="text" name="senha_certificado" class="form-control" placeholder="Senha para extrair...">
                        </div>
                        <div class="col-md-3">
                            <button class="btn btn-primary w-100">⬆️ Enviar Arquivo</button>
                        </div>
                    </form>

                    <h5 class="text-white">Arquivos Anexados</h5>
                    <table class="table table-dark table-sm mt-3">
                        <thead><tr><th>Nome Arquivo</th><th>Data Upload</th><th>Senha</th><th>Ação</th></tr></thead>
                        <tbody>
                            <?php foreach($certificados as $cert): ?>
                            <tr>
                                <td><?= $cert['arquivo_nome'] ?></td>
                                <td><?= date('d/m/Y H:i', strtotime($cert['data_upload'])) ?></td>
                                <td class="text-info"><?= $cert['senha_winrar'] ?></td>
                                <td><a href="<?= $cert['caminho_arquivo'] ?>" target="_blank" class="btn btn-sm btn-outline-light">Baixar</a></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(empty($certificados)) echo "<tr><td colspan='4' class='text-muted text-center py-3'>Nenhum certificado anexado.</td></tr>"; ?>
                        </tbody>
                    </table>
                </div>

                <div class="tab-pane fade" id="produtos">
                    <h5 class="text-white mb-3">Produtos e Serviços Adquiridos</h5>
                    <div class="alert alert-dark border-secondary">
                        <small>Listagem automática baseada nos Pedidos com status 'Fechado/Pago'.</small>
                    </div>
                    <table class="table table-dark table-striped">
                        <thead><tr><th>Produto/Serviço</th><th>Qtd</th><th>Valor Un.</th><th>Data Compra</th></tr></thead>
                        <tbody>
                            <?php if(empty($produtos)): ?>
                                <tr><td colspan="4" class="text-center text-muted">Nenhuma compra registrada ainda.</td></tr>
                            <?php else: ?>
                                <?php foreach($produtos as $prod): ?>
                                <tr>
                                    <td><?= $prod['nome'] ?></td>
                                    <td><?= $prod['quantidade'] ?></td>
                                    <td>R$ <?= number_format($prod['valor_unitario'], 2, ',', '.') ?></td>
                                    <td><?= date('d/m/Y', strtotime($prod['data_emissao'])) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="tab-pane fade" id="posvenda">
                    <form method="POST" class="mb-4">
                        <input type="hidden" name="salvar_posvenda" value="1">
                        <input type="hidden" name="id" value="<?= $cliente['id'] ?>">
                        <label>Nova Anotação / Contato de Pós-Venda</label>
                        <textarea name="obs_posvenda" class="form-control mb-2" rows="3" placeholder="Ex: Entrei em contato para verificar satisfação..."></textarea>
                        <button class="btn btn-info">Registrar Histórico</button>
                    </form>

                    <div class="list-group">
                        <?php foreach($pos_vendas as $pv): ?>
                        <div class="list-group-item bg-dark text-white border-secondary mb-2">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-1 text-info"><?= $pv['usuario'] ?></h6>
                                <small><?= date('d/m/Y H:i', strtotime($pv['data_registro'])) ?></small>
                            </div>
                            <p class="mb-1 text-muted"><?= nl2br($pv['texto']) ?></p>
                        </div>
                        <?php endforeach; ?>
                        <?php if(empty($pos_vendas)) echo "<p class='text-muted'>Nenhum registro de pós-venda.</p>"; ?>
                    </div>
                </div>

                <div class="tab-pane fade" id="ocorrencias">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="text-white">Histórico de Chamados</h5>
                        <a href="ocorrencias.php?cliente_id=<?= $cliente['id'] ?>" class="btn btn-sm btn-outline-warning">Abrir Nova Ocorrência</a>
                    </div>
                    <table class="table table-dark table-hover">
                        <thead><tr><th>#ID</th><th>Assunto</th><th>Status</th><th>Técnico</th><th>Data</th></tr></thead>
                        <tbody>
                            <?php foreach($ocorrencias as $oco): ?>
                            <tr>
                                <td>#<?= $oco['id'] ?></td>
                                <td><?= $oco['assunto'] ?></td>
                                <td><span class="badge bg-<?= $oco['status']=='Aberto'?'danger':'success' ?>"><?= $oco['status'] ?></span></td>
                                <td><?= $oco['tecnico_id'] ?? '--' ?></td>
                                <td><?= date('d/m/Y', strtotime($oco['data_abertura'])) ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(empty($ocorrencias)) echo "<tr><td colspan='5' class='text-center text-muted'>Nenhuma ocorrência registrada.</td></tr>"; ?>
                        </tbody>
                    </table>
                </div>

            </div> <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // --- API DE CEP (ViaCEP) ---
        function buscarCEP() {
            let cep = document.getElementById('cep').value.replace(/\D/g, '');
            if (cep.length === 8) {
                fetch(`https://viacep.com.br/ws/${cep}/json/`)
                    .then(res => res.json())
                    .then(data => {
                        if (!data.erro) {
                            document.getElementById('endereco').value = data.logradouro;
                            document.getElementById('bairro').value = data.bairro;
                            document.getElementById('cidade').value = data.localidade;
                            document.getElementById('uf').value = data.uf;
                        } else {
                            alert("CEP não encontrado!");
                        }
                    });
            }
        }

        // --- API DE CNPJ (BrasilAPI) ---
        function buscarCNPJ() {
            let cnpj = document.getElementById('cnpj').value.replace(/\D/g, '');
            if (cnpj.length === 14) {
                // Aviso visual de carregando
                let btn = event.target;
                let originalText = btn.innerText;
                btn.innerText = "Carregando...";
                
                // Usando BrasilAPI (Gratuita e sem chave)
                fetch(`https://brasilapi.com.br/api/cnpj/v1/${cnpj}`)
                    .then(res => {
                        if(!res.ok) throw new Error('Erro na busca');
                        return res.json();
                    })
                    .then(data => {
                        document.getElementById('razao').value = data.razao_social;
                        document.getElementById('fantasia').value = data.nome_fantasia || data.razao_social;
                        
                        // Preenche endereço se vier na API
                        if(data.cep) {
                            document.getElementById('cep').value = data.cep;
                            document.getElementById('endereco').value = data.logradouro + ', ' + data.numero;
                            document.getElementById('bairro').value = data.bairro;
                            document.getElementById('cidade').value = data.municipio;
                            document.getElementById('uf').value = data.uf;
                        }
                        btn.innerText = originalText;
                    })
                    .catch(err => {
                        alert("CNPJ não encontrado ou erro na API.");
                        btn.innerText = originalText;
                    });
            } else {
                alert("Digite um CNPJ válido com 14 números.");
            }
        }
    </script>
</body>
</html>