<div class="kanban-card" data-id="<?= $card['id'] ?>">
    <h5><?= $card['nome_fantasia'] ?></h5>
    <p><?= substr($card['motivo_desc'], 0, 50) ?>...</p>
    <div class="d-flex justify-content-between align-items-center mt-2">
        <span class="badge-user"><?= $card['tecnico'] ?: 'Sem Resp.' ?></span>
        <a href="ocorrencias.php?id=<?= $card['ocorrencia_id'] ?>" class="text-info small" style="text-decoration:none;">Ver ➜</a>
    </div>
</div>