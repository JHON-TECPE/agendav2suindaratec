<?php
// Arquivo: ocorrencias.php
require 'includes/auth.php';
require 'includes/db.php';

$view = isset($_GET['view']) ? $_GET['view'] : 'lista';
$msg = '';

// --- SALVAR ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $dados = [
            $_POST['cliente_id'], $_POST['tecnico_id'] ?: null, $_POST['solicitante'], 
            $_POST['assunto'], $_POST['status'], $_POST['motivo_desc']
        ];

        if ($_POST['acao'] == 'novo') {
            $sql = "INSERT INTO ocorrencias (cliente_id, tecnico_id, solicitante, assunto, status, motivo_desc, data_abertura) VALUES (?, ?, ?, ?, ?, ?, NOW())";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($dados);
            $msg = "Ocorrência aberta com sucesso!";
        } else {
            // Update
            $id = $_POST['id'];
            $sql = "UPDATE ocorrencias SET cliente_id=?, tecnico_id=?, solicitante=?, assunto=?, status=?, motivo_desc=?, data_retorno=?, servico_realizado=? WHERE id=?";
            $param_extra = [$_POST['data_retorno']?:null, $_POST['servico_realizado'], $id];
            $stmt = $pdo->prepare($sql);
            $stmt->execute(array_merge($dados, $param_extra));
            $msg = "Ocorrência atualizada!";
        }
        $view = 'lista';
    } catch (PDOException $e) {
        $msg = "Erro: " . $e->getMessage();
    }
}

// --- DADOS PARA O FORMULÁRIO ---
$clientes = $pdo->query("SELECT id, nome_fantasia, razao_social FROM clientes ORDER BY nome_fantasia")->fetchAll();
$tecnicos = $pdo->query("SELECT id, nome FROM usuarios WHERE funcao IN ('Técnico', 'Administrador')")->fetchAll();
$ocorrencia = null;

if (isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM ocorrencias WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $ocorrencia = $stmt->fetch();
    if($ocorrencia) $view = 'form';
}

// Se veio do botão "Nova Ocorrência" lá do cadastro de cliente
$pre_cliente_id = $_GET['cliente_id'] ?? '';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Ocorrências - Suindara v2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        
        <?php if($view == 'lista'): ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="text-white">Central de Ocorrências</h3>
                <a href="?view=form" class="btn btn-info fw-bold" style="background: var(--neon-blue); border:none; color:black;">+ Nova Ocorrência</a>
            </div>

            <?php if($msg) echo "<div class='alert alert-success'>$msg</div>"; ?>

            <div class="mb-3">
                <a href="ocorrencias.php" class="btn btn-sm btn-outline-light">Todas</a>
                <a href="?filtro=Aberto" class="btn btn-sm btn-outline-danger">Abertas</a>
                <a href="?filtro=Em Andamento" class="btn btn-sm btn-outline-warning">Em Andamento</a>
                <a href="?filtro=Concluido" class="btn btn-sm btn-outline-success">Concluídas</a>
            </div>

            <div class="card card-custom p-0 table-responsive">
                <table class="table table-dark table-hover mb-0">
                    <thead>
                        <tr>
                            <th>#ID</th>
                            <th>Cliente</th>
                            <th>Assunto</th>
                            <th>Técnico</th>
                            <th>Status</th>
                            <th>Data</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $where = "";
                        if(isset($_GET['filtro'])) $where = "WHERE o.status = '".$_GET['filtro']."'";
                        
                        $sql = "SELECT o.*, c.nome_fantasia, u.nome as tecnico_nome 
                                FROM ocorrencias o 
                                JOIN clientes c ON o.cliente_id = c.id 
                                LEFT JOIN usuarios u ON o.tecnico_id = u.id 
                                $where 
                                ORDER BY o.id DESC LIMIT 50";
                        $lista = $pdo->query($sql)->fetchAll();
                        
                        foreach($lista as $o): 
                            $badge = match($o['status']) {
                                'Aberto' => 'bg-danger',
                                'Em Andamento' => 'bg-warning text-dark',
                                'Concluido' => 'bg-success',
                                default => 'bg-secondary'
                            };
                        ?>
                        <tr>
                            <td>#<?= $o['id'] ?></td>
                            <td><?= $o['nome_fantasia'] ?></td>
                            <td><?= $o['assunto'] ?><br><small class="text-muted"><?= $o['solicitante'] ?></small></td>
                            <td><?= $o['tecnico_nome'] ?? '---' ?></td>
                            <td><span class="badge <?= $badge ?>"><?= $o['status'] ?></span></td>
                            <td><?= date('d/m H:i', strtotime($o['data_abertura'])) ?></td>
                            <td><a href="?id=<?= $o['id'] ?>" class="btn btn-sm btn-outline-info">Ver</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php else: ?>
            <div class="d-flex justify-content-between mb-3">
                <h3 class="text-white"><?= $ocorrencia ? 'Editar' : 'Nova' ?> Ocorrência <?= $ocorrencia ? '#'.$ocorrencia['id'] : '' ?></h3>
                <a href="ocorrencias.php" class="btn btn-outline-secondary">Voltar</a>
            </div>

            <form method="POST">
                <input type="hidden" name="acao" value="<?= $ocorrencia ? 'editar' : 'novo' ?>">
                <?php if($ocorrencia): ?><input type="hidden" name="id" value="<?= $ocorrencia['id'] ?>"><?php endif; ?>

                <div class="row">
                    <div class="col-md-8">
                        <div class="card card-custom p-4">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label>Cliente</label>
                                    <select name="cliente_id" class="form-select select2" required>
                                        <option value="">Selecione...</option>
                                        <?php foreach($clientes as $c): ?>
                                        <option value="<?= $c['id'] ?>" <?= ($ocorrencia['cliente_id']??$pre_cliente_id)==$c['id']?'selected':'' ?>>
                                            <?= $c['nome_fantasia'] ?: $c['razao_social'] ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label>Solicitante (Quem pediu?)</label>
                                    <input type="text" name="solicitante" class="form-control" value="<?= $ocorrencia['solicitante']??'' ?>">
                                </div>
                                <div class="col-md-12">
                                    <label>Assunto / Título</label>
                                    <select name="assunto" class="form-select">
                                        <option value="Suporte Técnico" <?= ($ocorrencia['assunto']??'')=='Suporte Técnico'?'selected':'' ?>>Suporte Técnico</option>
                                        <option value="Erro no Sistema" <?= ($ocorrencia['assunto']??'')=='Erro no Sistema'?'selected':'' ?>>Erro no Sistema</option>
                                        <option value="Dúvida" <?= ($ocorrencia['assunto']??'')=='Dúvida'?'selected':'' ?>>Dúvida Operacional</option>
                                        <option value="Instalação" <?= ($ocorrencia['assunto']??'')=='Instalação'?'selected':'' ?>>Instalação / Configuração</option>
                                        <option value="Venda" <?= ($ocorrencia['assunto']??'')=='Venda'?'selected':'' ?>>Oportunidade de Venda</option>
                                    </select>
                                </div>
                                <div class="col-md-12">
                                    <label>Descrição Detalhada</label>
                                    <textarea name="motivo_desc" rows="5" class="form-control"><?= $ocorrencia['motivo_desc']??'' ?></textarea>
                                </div>
                                
                                <?php if($ocorrencia): ?>
                                <div class="col-md-12 border-top border-secondary pt-3 mt-3">
                                    <label class="text-info">Solução / Serviço Realizado</label>
                                    <textarea name="servico_realizado" rows="3" class="form-control bg-dark"><?= $ocorrencia['servico_realizado']??'' ?></textarea>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card card-custom p-4">
                            <div class="mb-3">
                                <label>Status Atual</label>
                                <select name="status" class="form-select form-select-lg mb-3">
                                    <option value="Aberto" class="text-danger" <?= ($ocorrencia['status']??'')=='Aberto'?'selected':'' ?>>🔴 Aberto</option>
                                    <option value="Em Andamento" class="text-warning" <?= ($ocorrencia['status']??'')=='Em Andamento'?'selected':'' ?>>🟡 Em Andamento</option>
                                    <option value="Concluido" class="text-success" <?= ($ocorrencia['status']??'')=='Concluido'?'selected':'' ?>>🟢 Concluído</option>
                                    <option value="Cancelado" class="text-muted" <?= ($ocorrencia['status']??'')=='Cancelado'?'selected':'' ?>>⚪ Cancelado</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label>Técnico Responsável</label>
                                <select name="tecnico_id" class="form-select">
                                    <option value="">-- Aguardando --</option>
                                    <?php foreach($tecnicos as $t): ?>
                                        <option value="<?= $t['id'] ?>" <?= ($ocorrencia['tecnico_id']??'')==$t['id']?'selected':'' ?>><?= $t['nome'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label>Agendar Retorno (Opcional)</label>
                                <input type="datetime-local" name="data_retorno" class="form-control" value="<?= $ocorrencia['data_retorno']??'' ?>">
                            </div>

                            <button type="submit" class="btn btn-success w-100 fw-bold py-2 mt-2">
                                <?= $ocorrencia ? 'SALVAR ALTERAÇÕES' : 'ABRIR CHAMADO' ?>
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>