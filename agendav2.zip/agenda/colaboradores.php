<?php
// Arquivo: colaboradores.php
require 'includes/auth.php';
require 'includes/db.php';

$msg = '';
$erro = '';

// 1. Salvar / Atualizar
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['acao'])) {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $funcao = $_POST['funcao'];
    $senha = $_POST['senha'];
    
    try {
        if ($_POST['acao'] == 'novo') {
            // Hash da senha para segurança
            $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
            $sql = "INSERT INTO usuarios (nome, email, senha, funcao) VALUES (?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$nome, $email, $senha_hash, $funcao]);
            $msg = "Colaborador cadastrado com sucesso!";
        } 
        elseif ($_POST['acao'] == 'editar') {
            $id = $_POST['id'];
            // Só atualiza senha se o campo não estiver vazio
            if (!empty($senha)) {
                $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
                $sql = "UPDATE usuarios SET nome=?, email=?, senha=?, funcao=? WHERE id=?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$nome, $email, $senha_hash, $funcao, $id]);
            } else {
                $sql = "UPDATE usuarios SET nome=?, email=?, funcao=? WHERE id=?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$nome, $email, $funcao, $id]);
            }
            $msg = "Dados atualizados!";
        }
        elseif ($_POST['acao'] == 'excluir') {
            $id = $_POST['id'];
            if ($id != $_SESSION['user_id']) { // Não pode se auto-excluir
                $pdo->prepare("DELETE FROM usuarios WHERE id=?")->execute([$id]);
                $msg = "Usuário removido.";
            } else {
                $erro = "Você não pode excluir seu próprio usuário!";
            }
        }
    } catch (PDOException $e) {
        $erro = "Erro no banco: " . $e->getMessage();
    }
}

// 2. Buscar Dados
$colaboradores = $pdo->query("SELECT * FROM usuarios ORDER BY nome")->fetchAll();
$edit_user = null;

// Se clicou em editar
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $edit_user = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Colaboradores - Suindara v2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <h3 class="text-white mb-4">Gestão de Colaboradores</h3>

        <?php if($msg) echo "<div class='alert alert-success'>$msg</div>"; ?>
        <?php if($erro) echo "<div class='alert alert-danger'>$erro</div>"; ?>

        <div class="row">
            <div class="col-md-4">
                <div class="card card-custom p-3">
                    <h5 class="text-info"><?= $edit_user ? 'Editar' : 'Novo' ?> Colaborador</h5>
                    <form method="POST">
                        <input type="hidden" name="acao" value="<?= $edit_user ? 'editar' : 'novo' ?>">
                        <?php if($edit_user): ?><input type="hidden" name="id" value="<?= $edit_user['id'] ?>"><?php endif; ?>

                        <div class="mb-3">
                            <label>Nome</label>
                            <input type="text" name="nome" class="form-control" required value="<?= $edit_user['nome']??'' ?>">
                        </div>
                        <div class="mb-3">
                            <label>E-mail (Login)</label>
                            <input type="email" name="email" class="form-control" required value="<?= $edit_user['email']??'' ?>">
                        </div>
                        <div class="mb-3">
                            <label>Função</label>
                            <select name="funcao" class="form-select">
                                <option value="Administrador" <?= ($edit_user['funcao']??'')=='Administrador'?'selected':'' ?>>Administrador</option>
                                <option value="Técnico" <?= ($edit_user['funcao']??'')=='Técnico'?'selected':'' ?>>Técnico</option>
                                <option value="Comercial" <?= ($edit_user['funcao']??'')=='Comercial'?'selected':'' ?>>Comercial</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label>Senha <?= $edit_user ? '(Deixe vazio para manter)' : '' ?></label>
                            <input type="password" name="senha" class="form-control" <?= $edit_user ? '' : 'required' ?>>
                        </div>
                        
                        <button class="btn btn-info w-100 fw-bold">Salvar</button>
                        <?php if($edit_user): ?>
                            <a href="colaboradores.php" class="btn btn-outline-secondary w-100 mt-2">Cancelar</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card card-custom p-3 table-responsive">
                    <table class="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Função</th>
                                <th>Email</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($colaboradores as $u): ?>
                            <tr>
                                <td><?= $u['nome'] ?></td>
                                <td><span class="badge bg-secondary"><?= $u['funcao'] ?></span></td>
                                <td><?= $u['email'] ?></td>
                                <td>
                                    <a href="?edit=<?= $u['id'] ?>" class="btn btn-sm btn-primary">✏️</a>
                                    <form method="POST" class="d-inline" onsubmit="return confirm('Tem certeza?');">
                                        <input type="hidden" name="acao" value="excluir">
                                        <input type="hidden" name="id" value="<?= $u['id'] ?>">
                                        <button class="btn btn-sm btn-danger">🗑️</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>