<?php
// Arquivo: pedidos.php
require 'includes/auth.php';
require 'includes/db.php';

$msg = '';

// --- ALTERAR STATUS DO PEDIDO ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['acao'])) {
    if ($_POST['acao'] == 'mudar_status') {
        $id = $_POST['id'];
        $novo_status = $_POST['status'];
        
        $pdo->prepare("UPDATE pedidos_orcamentos SET status = ? WHERE id = ?")->execute([$novo_status, $id]);
        $msg = "Status do pedido #$id atualizado para '$novo_status'.";
    }
}

// Mensagem vinda da aprovação de orçamento
if (isset($_GET['msg']) && $_GET['msg'] == 'aprovado') {
    $msg = "Orçamento aprovado com sucesso! Ele agora é um PEDIDO.";
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Pedidos de Venda - Suindara v2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css?v=2" rel="stylesheet">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="text-white">Pedidos e Vendas</h3>
            <a href="orcamentos.php" class="btn btn-outline-info">Ver Orçamentos</a>
        </div>

        <?php if($msg) echo "<div class='alert alert-success'>$msg</div>"; ?>

        <div class="card card-custom p-0 table-responsive">
            <table class="table table-dark table-hover mb-0 align-middle">
                <thead>
                    <tr>
                        <th>#ID</th>
                        <th>Cliente</th>
                        <th>Emissão</th>
                        <th>Valor Total</th>
                        <th>Status Atual</th>
                        <th class="text-end">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    // Busca apenas o que é TIPO = 'pedido'
                    $sql = "SELECT p.*, c.nome_fantasia 
                            FROM pedidos_orcamentos p 
                            JOIN clientes c ON p.cliente_id = c.id 
                            WHERE p.tipo = 'pedido' 
                            ORDER BY p.id DESC";
                    $lista = $pdo->query($sql)->fetchAll();

                    foreach($lista as $p): 
                        $badge = match($p['status']) {
                            'Aprovado' => 'bg-info text-dark',
                            'Em Produção' => 'bg-warning text-dark',
                            'Entregue' => 'bg-primary',
                            'Pago/Finalizado' => 'bg-success',
                            'Cancelado' => 'bg-danger',
                            default => 'bg-secondary'
                        };
                    ?>
                    <tr>
                        <td><strong>#<?= $p['id'] ?></strong></td>
                        <td><?= $p['nome_fantasia'] ?></td>
                        <td><?= date('d/m/Y', strtotime($p['data_emissao'])) ?></td>
                        <td class="text-success fw-bold">R$ <?= number_format($p['valor_total'], 2, ',', '.') ?></td>
                        <td><span class="badge <?= $badge ?>"><?= $p['status'] ?></span></td>
                        <td class="text-end">
                            <button class="btn btn-sm btn-outline-light me-2" data-bs-toggle="modal" data-bs-target="#modalStatus<?= $p['id'] ?>">🔄 Status</button>
                            <a href="imprimir_orcamento.php?id=<?= $p['id'] ?>" target="_blank" class="btn btn-sm btn-info fw-bold">📄 Imprimir</a>
                        </td>
                    </tr>

                    <div class="modal fade" id="modalStatus<?= $p['id'] ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content bg-dark border-secondary">
                                <div class="modal-header">
                                    <h5 class="modal-title text-white">Atualizar Pedido #<?= $p['id'] ?></h5>
                                    <button class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                </div>
                                <form method="POST">
                                    <div class="modal-body">
                                        <input type="hidden" name="acao" value="mudar_status">
                                        <input type="hidden" name="id" value="<?= $p['id'] ?>">
                                        
                                        <label>Novo Status:</label>
                                        <select name="status" class="form-select mt-2">
                                            <option value="Aprovado" <?= $p['status']=='Aprovado'?'selected':'' ?>>Aprovado (Aguardando)</option>
                                            <option value="Em Produção" <?= $p['status']=='Em Produção'?'selected':'' ?>>Em Produção / Separação</option>
                                            <option value="Entregue" <?= $p['status']=='Entregue'?'selected':'' ?>>Entregue (Aguardando Pagto)</option>
                                            <option value="Pago/Finalizado" <?= $p['status']=='Pago/Finalizado'?'selected':'' ?>>Pago & Finalizado</option>
                                            <option value="Cancelado" <?= $p['status']=='Cancelado'?'selected':'' ?>>Cancelado</option>
                                        </select>
                                    </div>
                                    <div class="modal-footer">
                                        <button class="btn btn-success w-100">Salvar Alteração</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>