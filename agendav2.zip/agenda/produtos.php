<?php
// Arquivo: produtos.php
require 'includes/auth.php';
require 'includes/db.php';

$msg = '';
$erro = '';

// --- SALVAR ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $tipo = $_POST['tipo'];
    $preco_venda = str_replace(',', '.', $_POST['preco_venda']); // Troca virgula por ponto
    $unidade = $_POST['unidade'];
    
    try {
        if ($_POST['acao'] == 'novo') {
            $stmt = $pdo->prepare("INSERT INTO produtos (nome, tipo, preco_venda, unidade) VALUES (?, ?, ?, ?)");
            $stmt->execute([$nome, $tipo, $preco_venda, $unidade]);
            $msg = "Item cadastrado com sucesso!";
        } elseif ($_POST['acao'] == 'editar') {
            $id = $_POST['id'];
            $stmt = $pdo->prepare("UPDATE produtos SET nome=?, tipo=?, preco_venda=?, unidade=? WHERE id=?");
            $stmt->execute([$nome, $tipo, $preco_venda, $unidade, $id]);
            $msg = "Item atualizado!";
        } elseif ($_POST['acao'] == 'excluir') {
            $pdo->prepare("DELETE FROM produtos WHERE id=?")->execute([$_POST['id']]);
            $msg = "Item removido.";
        }
    } catch (PDOException $e) {
        $erro = "Erro ao salvar: " . $e->getMessage();
    }
}

// --- BUSCAR PARA EDIÇÃO ---
$edit_item = null;
if (isset($_GET['edit'])) {
    $edit_item = $pdo->query("SELECT * FROM produtos WHERE id = " . $_GET['edit'])->fetch();
}

// --- LISTAGEM ---
$produtos = $pdo->query("SELECT * FROM produtos ORDER BY nome")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Produtos e Serviços - Suindara v2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <h3 class="text-white mb-4">Catálogo de Itens</h3>

        <?php if($msg) echo "<div class='alert alert-success'>$msg</div>"; ?>

        <div class="row">
            <div class="col-md-4">
                <div class="card card-custom p-3">
                    <h5 class="text-info"><?= $edit_item ? 'Editar' : 'Novo' ?> Item</h5>
                    <form method="POST">
                        <input type="hidden" name="acao" value="<?= $edit_item ? 'editar' : 'novo' ?>">
                        <?php if($edit_item): ?><input type="hidden" name="id" value="<?= $edit_item['id'] ?>"><?php endif; ?>

                        <div class="mb-3">
                            <label>Nome do Item</label>
                            <input type="text" name="nome" class="form-control" required value="<?= $edit_item['nome']??'' ?>">
                        </div>
                        <div class="mb-3">
                            <label>Tipo</label>
                            <select name="tipo" class="form-select">
                                <option value="servico" <?= ($edit_item['tipo']??'')=='servico'?'selected':'' ?>>Serviço (Mão de Obra)</option>
                                <option value="produto" <?= ($edit_item['tipo']??'')=='produto'?'selected':'' ?>>Produto (Peça/Equipamento)</option>
                            </select>
                        </div>
                        <div class="row">
                            <div class="col-6 mb-3">
                                <label>Preço Venda</label>
                                <input type="text" name="preco_venda" class="form-control" placeholder="0.00" value="<?= $edit_item['preco_venda']??'' ?>">
                            </div>
                            <div class="col-6 mb-3">
                                <label>Unidade</label>
                                <input type="text" name="unidade" class="form-control" placeholder="UN/HR" value="<?= $edit_item['unidade']??'UN' ?>">
                            </div>
                        </div>
                        
                        <button class="btn btn-info w-100 fw-bold">SALVAR</button>
                        <?php if($edit_item): ?><a href="produtos.php" class="btn btn-outline-secondary w-100 mt-2">Cancelar</a><?php endif; ?>
                    </form>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card card-custom p-0 table-responsive">
                    <table class="table table-dark table-hover mb-0">
                        <thead><tr><th>Nome</th><th>Tipo</th><th>Preço</th><th>Ações</th></tr></thead>
                        <tbody>
                            <?php foreach($produtos as $p): ?>
                            <tr>
                                <td><?= $p['nome'] ?></td>
                                <td>
                                    <?php if($p['tipo']=='servico'): ?>
                                        <span class="badge bg-primary">Serviço</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark">Produto</span>
                                    <?php endif; ?>
                                </td>
                                <td>R$ <?= number_format($p['preco_venda'], 2, ',', '.') ?></td>
                                <td>
                                    <a href="?edit=<?= $p['id'] ?>" class="btn btn-sm btn-outline-light">✏️</a>
                                    <form method="POST" class="d-inline" onsubmit="return confirm('Apagar item?');">
                                        <input type="hidden" name="acao" value="excluir">
                                        <input type="hidden" name="id" value="<?= $p['id'] ?>">
                                        <button class="btn btn-sm btn-outline-danger">🗑️</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>