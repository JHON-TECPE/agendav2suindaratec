<?php
// Arquivo: kanban.php
require 'includes/auth.php';
require 'includes/db.php';

// --- API INTERNA PARA ATUALIZAR CARD AO ARRASTAR ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['acao']) && $_POST['acao'] == 'mover') {
    $id = $_POST['card_id'];
    $nova_etapa = $_POST['nova_etapa'];
    
    $stmt = $pdo->prepare("UPDATE kanban_cards SET etapa = ?, atualizado_em = NOW() WHERE id = ?");
    $stmt->execute([$nova_etapa, $id]);
    exit; // Para aqui se for requisição AJAX
}

// Criar card manualmente (se precisar)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['novo_card'])) {
    // Primeiro cria uma ocorrencia simples de venda
    $sql_oco = "INSERT INTO ocorrencias (cliente_id, assunto, status, motivo_desc) VALUES (?, 'Venda', 'Aberto', ?)";
    $pdo->prepare($sql_oco)->execute([$_POST['cliente_id'], $_POST['descricao']]);
    $oco_id = $pdo->lastInsertId();

    // Depois cria o card
    $pdo->prepare("INSERT INTO kanban_cards (ocorrencia_id, etapa) VALUES (?, 'Prospeccao')")->execute([$oco_id]);
    header("Location: kanban.php");
    exit;
}

// Sincronizar: Se existe ocorrência 'Venda' sem card, cria o card automaticamente
$pdo->exec("INSERT INTO kanban_cards (ocorrencia_id, etapa) 
            SELECT id, 'Prospeccao' FROM ocorrencias 
            WHERE assunto = 'Venda' AND id NOT IN (SELECT ocorrencia_id FROM kanban_cards)");

// Buscar Cards
$cards = $pdo->query("SELECT k.*, o.assunto, o.motivo_desc, c.nome_fantasia, u.nome as tecnico 
                      FROM kanban_cards k 
                      JOIN ocorrencias o ON k.ocorrencia_id = o.id 
                      JOIN clientes c ON o.cliente_id = c.id
                      LEFT JOIN usuarios u ON o.tecnico_id = u.id")->fetchAll();

// Organizar por colunas
$colunas = [
    'Prospeccao' => [],
    'Negociacao' => [],
    'Fechamento' => [],
    'PosVenda' => []
];

foreach($cards as $c) {
    if(isset($colunas[$c['etapa']])) {
        $colunas[$c['etapa']][] = $c;
    }
}

$clientes = $pdo->query("SELECT id, nome_fantasia FROM clientes ORDER BY nome_fantasia")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Fluxo Comercial - Suindara v2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css?v=2" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.14.0/Sortable.min.js"></script>
    <style>
        .kanban-board { display: flex; gap: 20px; overflow-x: auto; padding-bottom: 20px; height: calc(100vh - 150px); }
        .kanban-col { background: #1a1a1a; min-width: 300px; max-width: 300px; border-radius: 8px; border: 1px solid #333; display: flex; flex-direction: column; }
        .kanban-header { padding: 15px; border-bottom: 1px solid #333; font-weight: bold; text-align: center; color: var(--neon-blue); }
        .kanban-body { padding: 10px; flex-grow: 1; overflow-y: auto; }
        .kanban-card { background: #2c2c2c; padding: 15px; margin-bottom: 10px; border-radius: 5px; cursor: grab; border-left: 3px solid var(--neon-blue); box-shadow: 0 2px 4px rgba(0,0,0,0.2); }
        .kanban-card:hover { background: #333; }
        .kanban-card h5 { font-size: 1rem; color: #fff; margin-bottom: 5px; }
        .kanban-card p { font-size: 0.85rem; color: #aaa; margin-bottom: 5px; }
        .badge-user { font-size: 0.7rem; background: #444; padding: 2px 6px; border-radius: 4px; }
    </style>
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="text-white">Fluxo Comercial (Kanban)</h3>
            <button class="btn btn-info fw-bold" data-bs-toggle="modal" data-bs-target="#modalCard">+ Novo Card</button>
        </div>

        <div class="kanban-board">
            <div class="kanban-col">
                <div class="kanban-header border-info">🔍 Prospecção</div>
                <div class="kanban-body" id="Prospeccao">
                    <?php foreach($colunas['Prospeccao'] as $card): ?>
                        <?php include 'includes/card_template.php'; ?>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="kanban-col">
                <div class="kanban-header text-warning border-warning">💬 Negociação</div>
                <div class="kanban-body" id="Negociacao">
                    <?php foreach($colunas['Negociacao'] as $card): ?>
                        <?php include 'includes/card_template.php'; ?>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="kanban-col">
                <div class="kanban-header text-success border-success">✅ Fechamento</div>
                <div class="kanban-body" id="Fechamento">
                    <?php foreach($colunas['Fechamento'] as $card): ?>
                        <?php include 'includes/card_template.php'; ?>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="kanban-col">
                <div class="kanban-header text-primary border-primary">🤝 Pós-Venda</div>
                <div class="kanban-body" id="PosVenda">
                    <?php foreach($colunas['PosVenda'] as $card): ?>
                        <?php include 'includes/card_template.php'; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modalCard" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content bg-dark border-secondary">
                <div class="modal-header"><h5 class="text-white">Nova Oportunidade</h5><button class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="novo_card" value="1">
                        <div class="mb-3">
                            <label>Cliente</label>
                            <select name="cliente_id" class="form-select" required>
                                <?php foreach($clientes as $c): ?><option value="<?= $c['id'] ?>"><?= $c['nome_fantasia'] ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label>O que está sendo negociado?</label>
                            <textarea name="descricao" class="form-control" rows="3" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer"><button class="btn btn-info">Criar Card</button></div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Ativar Arrastar e Soltar nas 4 colunas
        ['Prospeccao', 'Negociacao', 'Fechamento', 'PosVenda'].forEach(id => {
            new Sortable(document.getElementById(id), {
                group: 'shared', // Permite mover entre colunas
                animation: 150,
                onEnd: function (evt) {
                    let itemEl = evt.item;
                    let novaEtapa = evt.to.id; // ID da coluna onde soltou
                    let cardId = itemEl.getAttribute('data-id');

                    // Envia AJAX para salvar no banco
                    fetch('kanban.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: `acao=mover&card_id=${cardId}&nova_etapa=${novaEtapa}`
                    });
                }
            });
        });
    </script>
</body>
</html>