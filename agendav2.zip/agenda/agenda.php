<?php
// Arquivo: agenda.php
require 'includes/auth.php';
require 'includes/db.php';

// Salvar Novo Agendamento
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['novo_evento'])) {
    $sql = "INSERT INTO agenda_eventos (cliente_id, colaborador_id, titulo, inicio, fim, cor) VALUES (?,?,?,?,?,?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $_POST['cliente_id'], $_POST['colaborador_id'], $_POST['titulo'], 
        $_POST['inicio'], $_POST['fim'], $_POST['cor']
    ]);
    header("Location: agenda.php");
    exit;
}

$clientes = $pdo->query("SELECT id, nome_fantasia FROM clientes ORDER BY nome_fantasia")->fetchAll();
$users = $pdo->query("SELECT id, nome FROM usuarios WHERE ativo=1")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Agenda Operacional - Suindara v2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css?v=2" rel="stylesheet">
    
    <link href='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css' rel='stylesheet' />
    <style>
        .fc-toolbar-title { color: white !important; font-size: 1.5rem !important; }
        .fc-button { background-color: var(--neon-blue) !important; border: none !important; color: #000 !important; font-weight: bold; }
        .fc-daygrid-day-number { color: #aaa; text-decoration: none; }
        .fc-col-header-cell-cushion { color: var(--neon-blue); text-decoration: none; }
        .fc-event { cursor: pointer; border: none; }
    </style>
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <h3 class="text-white mb-4">Agenda Operacional</h3>

        <div class="card card-custom p-3">
            <div id='calendar'></div>
        </div>
    </div>

    <div class="modal fade" id="modalEvento" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content bg-dark border border-secondary">
                <div class="modal-header border-secondary">
                    <h5 class="modal-title text-white">Novo Agendamento</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="novo_evento" value="1">
                        
                        <div class="mb-3">
                            <label>Título</label>
                            <input type="text" name="titulo" class="form-control" required placeholder="Ex: Instalação, Visita...">
                        </div>
                        <div class="mb-3">
                            <label>Cliente</label>
                            <select name="cliente_id" class="form-select" required>
                                <option value="">Selecione...</option>
                                <?php foreach($clientes as $c): ?>
                                    <option value="<?= $c['id'] ?>"><?= $c['nome_fantasia'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label>Técnico/Responsável</label>
                            <select name="colaborador_id" class="form-select">
                                <?php foreach($users as $u): ?>
                                    <option value="<?= $u['id'] ?>" <?= $u['id']==$_SESSION['user_id']?'selected':'' ?>><?= $u['nome'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="row">
                            <div class="col-6 mb-3">
                                <label>Início</label>
                                <input type="datetime-local" name="inicio" id="start_date" class="form-control" required>
                            </div>
                            <div class="col-6 mb-3">
                                <label>Fim</label>
                                <input type="datetime-local" name="fim" id="end_date" class="form-control" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label>Cor na Agenda</label>
                            <input type="color" name="cor" class="form-control form-control-color w-100" value="#00e5ff">
                        </div>
                    </div>
                    <div class="modal-footer border-secondary">
                        <button type="submit" class="btn btn-info fw-bold">Salvar na Agenda</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/locales/pt-br.js'></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                locale: 'pt-br',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                },
                events: 'api_eventos.php', // Busca do nosso backend
                editable: true,
                dateClick: function(info) {
                    // Abre modal ao clicar no dia
                    var modal = new bootstrap.Modal(document.getElementById('modalEvento'));
                    document.getElementById('start_date').value = info.dateStr + 'T09:00';
                    document.getElementById('end_date').value = info.dateStr + 'T10:00';
                    modal.show();
                },
                eventClick: function(info) {
                    if (info.event.url) {
                        return; // Se tiver URL (ocorrência), deixa o navegador abrir
                    }
                    alert('Evento: ' + info.event.title + '\n\n' + (info.event.extendedProps.description || ''));
                }
            });
            calendar.render();
        });
    </script>
</body>
</html>