<?php
// Arquivo: chat_interno.php
require 'includes/auth.php';
require 'includes/db.php';

// API para Salvar e Listar (AJAX)
if (isset($_GET['acao'])) {
    header('Content-Type: application/json');
    
    if ($_GET['acao'] == 'enviar' && !empty($_POST['msg'])) {
        $stmt = $pdo->prepare("INSERT INTO chat_mensagens (usuario_id, mensagem) VALUES (?, ?)");
        $stmt->execute([$_SESSION['user_id'], $_POST['msg']]);
        echo json_encode(['status' => 'ok']);
        exit;
    }
    
    if ($_GET['acao'] == 'listar') {
        // Pega as últimas 50 mensagens
        $sql = "SELECT c.*, u.nome FROM chat_mensagens c JOIN usuarios u ON c.usuario_id = u.id ORDER BY c.id ASC LIMIT 50";
        $msgs = $pdo->query($sql)->fetchAll();
        echo json_encode($msgs);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Chat Equipe - Suindara v2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css?v=2" rel="stylesheet">
    <style>
        .chat-container { height: calc(100vh - 180px); display: flex; flex-direction: column; }
        .chat-box { flex: 1; overflow-y: auto; padding: 20px; background: #1a1a1a; border: 1px solid #333; border-radius: 8px; margin-bottom: 15px; }
        .msg { margin-bottom: 15px; display: flex; flex-direction: column; }
        .msg.me { align-items: flex-end; }
        .msg.other { align-items: flex-start; }
        .bubble { max-width: 70%; padding: 10px 15px; border-radius: 15px; font-size: 0.95rem; position: relative; }
        .msg.me .bubble { background: var(--neon-blue); color: #000; border-bottom-right-radius: 2px; }
        .msg.other .bubble { background: #333; color: #fff; border-bottom-left-radius: 2px; }
        .msg-info { font-size: 0.75rem; color: #777; margin-top: 3px; }
    </style>
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <h3 class="text-white mb-3">💬 Chat da Equipe</h3>

        <div class="chat-container">
            <div class="chat-box" id="chatBox">
                <div class="text-center text-muted mt-5">Carregando mensagens...</div>
            </div>
            
            <form id="formChat" class="d-flex gap-2">
                <input type="text" id="inputMsg" class="form-control" placeholder="Digite sua mensagem..." autocomplete="off">
                <button type="submit" class="btn btn-info fw-bold" style="background: var(--neon-blue); border:none;">ENVIAR ✈️</button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        const chatBox = document.getElementById('chatBox');
        const inputMsg = document.getElementById('inputMsg');
        const userId = <?= $_SESSION['user_id'] ?>;

        // Enviar Mensagem
        document.getElementById('formChat').addEventListener('submit', function(e) {
            e.preventDefault();
            let msg = inputMsg.value.trim();
            if(!msg) return;

            let formData = new FormData();
            formData.append('msg', msg);

            fetch('chat_interno.php?acao=enviar', { method: 'POST', body: formData })
            .then(() => {
                inputMsg.value = '';
                carregarMensagens();
            });
        });

        // Carregar Mensagens
        function carregarMensagens() {
            fetch('chat_interno.php?acao=listar')
            .then(res => res.json())
            .then(data => {
                chatBox.innerHTML = '';
                data.forEach(m => {
                    let isMe = m.usuario_id == userId;
                    let cls = isMe ? 'me' : 'other';
                    let time = new Date(m.data_envio).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                    
                    let html = `
                        <div class="msg ${cls}">
                            <div class="bubble">${m.mensagem}</div>
                            <div class="msg-info">${isMe ? 'Você' : m.nome} • ${time}</div>
                        </div>
                    `;
                    chatBox.innerHTML += html;
                });
                chatBox.scrollTop = chatBox.scrollHeight; // Rola para baixo
            });
        }

        // Atualiza a cada 3 segundos
        setInterval(carregarMensagens, 3000);
        carregarMensagens(); // Primeira carga
    </script>
</body>
</html>