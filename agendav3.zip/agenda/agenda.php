<?php
// Arquivo: agenda.php

// --- ATIVAR VISUALIZAÇÃO DE ERROS ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'includes/auth.php';
require 'includes/db.php';

// --- LÓGICA DE SALVAR / EDITAR / EXCLUIR (APENAS PARA EVENTOS MANUAIS) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    if (isset($_POST['acao']) && $_POST['acao'] == 'salvar') {
        try {
            $id = $_POST['id'];
            $titulo = $_POST['titulo'];
            $cliente_id = !empty($_POST['cliente_id']) ? $_POST['cliente_id'] : null;
            $tecnico_id = $_POST['tecnico_id'];
            $inicio = $_POST['inicio'];
            $fim = $_POST['fim'];
            $cor = $_POST['cor'];
            $obs = $_POST['obs'] ?? ''; 

            if (!empty($id)) {
                $sql = "UPDATE agenda_eventos SET titulo=?, cliente_id=?, tecnico_id=?, inicio=?, fim=?, cor=?, observacoes=? WHERE id=?";
                $pdo->prepare($sql)->execute([$titulo, $cliente_id, $tecnico_id, $inicio, $fim, $cor, $obs, $id]);
            } else {
                $sql = "INSERT INTO agenda_eventos (titulo, cliente_id, tecnico_id, inicio, fim, cor, observacoes) VALUES (?, ?, ?, ?, ?, ?, ?)";
                $pdo->prepare($sql)->execute([$titulo, $cliente_id, $tecnico_id, $inicio, $fim, $cor, $obs]);
            }
            header("Location: agenda.php");
            exit;

        } catch (PDOException $e) {
            die("Erro ao salvar: " . $e->getMessage());
        }
    }

    if (isset($_POST['acao']) && $_POST['acao'] == 'excluir') {
        $id = $_POST['id'];
        $pdo->prepare("DELETE FROM agenda_eventos WHERE id=?")->execute([$id]);
        header("Location: agenda.php");
        exit;
    }
}

// --- CARREGAR DADOS ---
$clientes = $pdo->query("SELECT id, nome_fantasia FROM clientes ORDER BY nome_fantasia")->fetchAll();
$tecnicos = $pdo->query("SELECT id, nome FROM usuarios WHERE funcao IN ('Técnico', 'Administrador')")->fetchAll();
$eventos_json = [];

try {
    // 1. BUSCA EVENTOS MANUAIS (Tabela agenda_eventos)
    $sql_eventos = "SELECT e.*, c.nome_fantasia as cliente_nome, u.nome as tecnico_nome 
                    FROM agenda_eventos e 
                    LEFT JOIN clientes c ON e.cliente_id = c.id 
                    LEFT JOIN usuarios u ON e.tecnico_id = u.id";
    $eventos_db = $pdo->query($sql_eventos)->fetchAll(PDO::FETCH_ASSOC);

    foreach($eventos_db as $e) {
        $eventos_json[] = [
            'id' => $e['id'],
            'title' => $e['titulo'],
            'start' => $e['inicio'],
            'end' => $e['fim'],
            'backgroundColor' => $e['cor'],
            'borderColor' => $e['cor'],
            'extendedProps' => [
                'tipo' => 'manual', // Marcador para saber que é editável
                'cliente_id' => $e['cliente_id'],
                'tecnico_id' => $e['tecnico_id'],
                'obs' => $e['observacoes'] ?? '',
                'cliente_nome' => $e['cliente_nome'],
                'tecnico_nome' => $e['tecnico_nome']
            ]
        ];
    }

    // 2. BUSCA RETORNOS DE OCORRÊNCIAS (Tabela ocorrencias)
    // Mostramos apenas as que têm data_retorno preenchida e não estão canceladas
    $sql_ocos = "SELECT o.id, o.assunto, o.data_retorno, o.status, c.nome_fantasia 
                 FROM ocorrencias o 
                 JOIN clientes c ON o.cliente_id = c.id 
                 WHERE o.data_retorno IS NOT NULL AND o.status != 'Cancelado'";
    $ocos_db = $pdo->query($sql_ocos)->fetchAll(PDO::FETCH_ASSOC);

    foreach($ocos_db as $o) {
        // Criamos um evento de 1 hora de duração por padrão
        $inicio = $o['data_retorno'];
        $fim = date('Y-m-d H:i:s', strtotime($inicio . ' +1 hour'));
        
        // Define cor baseada no status
        $cor = ($o['status'] == 'Concluido') ? '#198754' : '#ff9800'; // Verde se concluído, Laranja se pendente

        $eventos_json[] = [
            'id' => 'oco_' . $o['id'], // ID diferente para não conflitar
            'title' => '🔧 ' . $o['nome_fantasia'] . ' (' . $o['assunto'] . ')',
            'start' => $inicio,
            'end' => $fim,
            'backgroundColor' => $cor,
            'borderColor' => $cor,
            'extendedProps' => [
                'tipo' => 'ocorrencia', // Marcador importante
                'real_id' => $o['id']
            ]
        ];
    }

} catch (PDOException $e) {
    die("Erro ao carregar agenda: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Agenda - Suindara v2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css?v=2" rel="stylesheet">
    <link href='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css' rel='stylesheet' />
    <style>
        .fc-event { cursor: pointer; }
        .fc-toolbar-title { color: white !important; }
        .fc-button { background-color: var(--neon-blue) !important; border: none; color: black !important; font-weight: bold; }
        .fc-daygrid-day-number { color: #ccc; text-decoration: none; }
        .fc-col-header-cell-cushion { color: white; text-decoration: none; }
        .fc-list-day-cushion { background-color: #333 !important; }
        .fc-list-event:hover td { background-color: #444 !important; }
    </style>
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="text-white">📅 Agenda de Serviços</h3>
            <div class="text-end">
                <span class="badge bg-primary me-2">🟦 Manual</span>
                <span class="badge bg-warning text-dark me-2">🟧 Ocorrência Aberta</span>
                <span class="badge bg-success">🟩 Ocorrência Concluída</span>
            </div>
            <button class="btn btn-info fw-bold ms-3" onclick="abrirModalNovo()">+ Novo Agendamento</button>
        </div>

        <div class="card card-custom p-3">
            <div id='calendar'></div>
        </div>
    </div>

    <div class="modal fade" id="modalEvento" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content bg-dark border-secondary">
                <div class="modal-header">
                    <h5 class="modal-title text-white" id="modalTitulo">Agendamento Manual</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="acao" value="salvar">
                        <input type="hidden" name="id" id="evento_id">

                        <div class="mb-3"><label class="text-white">Título</label><input type="text" name="titulo" id="titulo" class="form-control" required></div>
                        <div class="mb-3"><label class="text-white">Cliente</label>
                            <select name="cliente_id" id="cliente_id" class="form-select">
                                <option value="">Selecione...</option>
                                <?php foreach($clientes as $c): ?><option value="<?= $c['id'] ?>"><?= $c['nome_fantasia'] ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3"><label class="text-white">Técnico</label>
                            <select name="tecnico_id" id="tecnico_id" class="form-select" required>
                                <?php foreach($tecnicos as $t): ?><option value="<?= $t['id'] ?>"><?= $t['nome'] ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="row">
                            <div class="col-6 mb-3"><label class="text-white">Início</label><input type="datetime-local" name="inicio" id="inicio" class="form-control" required></div>
                            <div class="col-6 mb-3"><label class="text-white">Fim</label><input type="datetime-local" name="fim" id="fim" class="form-control" required></div>
                        </div>
                        <div class="mb-3"><label class="text-white">Obs</label><textarea name="obs" id="obs" class="form-control" rows="2"></textarea></div>
                        <div class="mb-3"><label class="text-white">Cor</label><input type="color" name="cor" id="cor" class="form-control form-control-color w-100" value="#00d4ff"></div>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-outline-danger" id="btnExcluir" onclick="excluirEvento()" style="display:none;">🗑️ Excluir</button>
                        <div>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-info fw-bold">Salvar</button>
                        </div>
                    </div>
                </form>
                <form id="formExcluir" method="POST" style="display:none;"><input type="hidden" name="acao" value="excluir"><input type="hidden" name="id" id="id_exclusao"></form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/locales/pt-br.js'></script>
    
    <script>
        var modal = new bootstrap.Modal(document.getElementById('modalEvento'));

        function formatarDataISO(dataStr) {
            if(!dataStr) return '';
            let date = new Date(dataStr);
            date.setMinutes(date.getMinutes() - date.getTimezoneOffset());
            return date.toISOString().slice(0,16);
        }

        function abrirModalNovo() {
            document.getElementById('evento_id').value = '';
            document.getElementById('titulo').value = '';
            document.getElementById('cliente_id').value = '';
            document.getElementById('obs').value = '';
            document.getElementById('inicio').value = '';
            document.getElementById('fim').value = '';
            document.getElementById('cor').value = '#00d4ff';
            document.getElementById('btnExcluir').style.display = 'none';
            document.getElementById('modalTitulo').innerText = 'Novo Agendamento';
            modal.show();
        }

        function excluirEvento() {
            if(confirm('Tem certeza?')) {
                document.getElementById('id_exclusao').value = document.getElementById('evento_id').value;
                document.getElementById('formExcluir').submit();
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                locale: 'pt-br',
                headerToolbar: { left: 'prev,next today', center: 'title', right: 'dayGridMonth,timeGridWeek,listWeek' },
                events: <?= json_encode($eventos_json) ?>,
                editable: false, // Desativei arraste para evitar conflito entre tipos
                selectable: true,

                select: function(info) {
                    abrirModalNovo();
                    document.getElementById('inicio').value = formatarDataISO(info.startStr);
                    let fim = new Date(info.startStr);
                    fim.setHours(fim.getHours() + 1);
                    document.getElementById('fim').value = formatarDataISO(fim);
                },
                
                eventClick: function(info) {
                    var props = info.event.extendedProps;

                    // SE FOR OCORRÊNCIA, VAI PARA A PÁGINA DELA
                    if (props.tipo === 'ocorrencia') {
                        window.location.href = 'ocorrencias.php?id=' + props.real_id;
                        return;
                    }

                    // SE FOR MANUAL, ABRE O MODAL
                    document.getElementById('evento_id').value = info.event.id;
                    document.getElementById('titulo').value = info.event.title;
                    document.getElementById('cliente_id').value = props.cliente_id;
                    document.getElementById('tecnico_id').value = props.tecnico_id;
                    document.getElementById('obs').value = props.obs;
                    document.getElementById('cor').value = info.event.backgroundColor;
                    document.getElementById('inicio').value = formatarDataISO(info.event.start);
                    document.getElementById('fim').value = info.event.end ? formatarDataISO(info.event.end) : formatarDataISO(info.event.start);
                    document.getElementById('btnExcluir').style.display = 'block';
                    document.getElementById('modalTitulo').innerText = 'Editar Agendamento';
                    modal.show();
                }
            });
            calendar.render();
        });
    </script>
</body>
</html>