<?php
require 'includes/db.php';

echo "<h2>🕵️ Diagnóstico de Banco de Dados</h2>";

// 1. Tenta Inserir um Cliente de Teste
echo "<p>Tentando inserir cliente de teste na tabela <strong>clientes</strong>...</p>";

try {
    $sql = "INSERT INTO clientes (tipo_pessoa, cnpj_cpf, razao_social, nome_fantasia, cep, endereco_completo, bairro, cidade, uf, horario_funcionamento, segmento, po_responsavel, escopo_desc) 
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'J', 
        '00000000000199', 
        'Teste Diagnóstico Ltda', 
        'Empresa Teste', 
        '00000-000', 
        'Rua Teste, 123', 
        'Bairro Teste', 
        'Cidade Teste', 
        'PE', 
        '08h as 18h', 
        'TI', 
        'Admin', 
        'Teste de inserção via script de diagnóstico'
    ]);
    
    $id = $pdo->lastInsertId();
    echo "<div style='color:green; font-weight:bold; border:1px solid green; padding:10px;'>✅ SUCESSO! A tabela 'clientes' está perfeita. ID gerado: $id</div>";
    
    // Limpa a sujeira
    $pdo->query("DELETE FROM clientes WHERE id = $id");

} catch (PDOException $e) {
    echo "<div style='color:red; background:#ffecec; border:1px solid red; padding:15px;'>
            <strong>❌ ERRO NA TABELA CLIENTES:</strong><br>
            " . $e->getMessage() . "
          </div>";
    
    // Ajuda a identificar o erro comum
    if (strpos($e->getMessage(), "Unknown column") !== false) {
        echo "<p>💡 <strong>Dica:</strong> O erro diz que uma coluna não existe. Verifique se o nome dos campos no banco está igual ao código.</p>";
    }
    if (strpos($e->getMessage(), "Data too long") !== false) {
        echo "<p>💡 <strong>Dica:</strong> Você tentou salvar um texto maior do que o campo permite (ex: Texto de 200 letras num campo varchar(100)).</p>";
    }
}

// 2. Lista as colunas que o banco tem de verdade
echo "<hr><h3>📋 Estrutura Atual da Tabela 'clientes':</h3>";
try {
    $colunas = $pdo->query("DESCRIBE clientes")->fetchAll(PDO::FETCH_ASSOC);
    echo "<table border='1' cellpadding='5' style='border-collapse:collapse;'>";
    echo "<tr style='background:#eee;'><th>Campo (Field)</th><th>Tipo (Type)</th><th>Nulo?</th><th>Extra</th></tr>";
    foreach ($colunas as $c) {
        echo "<tr>
                <td>{$c['Field']}</td>
                <td>{$c['Type']}</td>
                <td>{$c['Null']}</td>
                <td>{$c['Extra']}</td>
              </tr>";
    }
    echo "</table>";
} catch (Exception $e) {
    echo "Não foi possível ler a estrutura: " . $e->getMessage();
}
?>