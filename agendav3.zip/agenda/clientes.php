<?php
// Arquivo: clientes.php
require 'includes/auth.php';
require 'includes/db.php';

$view = isset($_GET['view']) ? $_GET['view'] : 'lista';
$msg = '';
$erro = '';

// --- LÓGICA DE SALVAMENTO ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $pdo->beginTransaction();

        // 1. Identifica qual botão foi clicado
        $acao = $_POST['acao_form'] ?? 'salvar_dados'; 

        // CASO 1: SALVAR DADOS GERAIS, FISCAL E REMOTO
        if ($acao == 'salvar_dados') {
            
            // --- FUNÇÕES DE LIMPEZA (ESSENCIAIS PARA NÃO DAR ERRO) ---
            function limparNum($val) {
                if(empty($val)) return 0.00;
                return str_replace(',', '.', $val);
            }
            function limparTexto($val) {
                return empty($val) ? null : trim($val);
            }

            // Prepara os dados tratando erros comuns
            $dados_cliente = [
                $_POST['tipo_pessoa'] ?? 'J',
                limparTexto($_POST['cnpj_cpf']),
                $_POST['razao_social'], 
                limparTexto($_POST['nome_fantasia']),
                limparTexto($_POST['cep']),
                limparTexto($_POST['endereco']),
                limparTexto($_POST['bairro']),
                limparTexto($_POST['cidade']),
                limparTexto($_POST['uf']),
                limparTexto($_POST['horario']),
                limparTexto($_POST['segmento']),
                limparTexto($_POST['po_resp']),
                limparTexto($_POST['escopo'])
            ];

            if ($_POST['id'] == 'novo') {
                $sql = "INSERT INTO clientes (tipo_pessoa, cnpj_cpf, razao_social, nome_fantasia, cep, endereco_completo, bairro, cidade, uf, horario_funcionamento, segmento, po_responsavel, escopo_desc) 
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute($dados_cliente);
                $cliente_id = $pdo->lastInsertId();
                
                $msg = "Cliente cadastrado com sucesso!";
                
                // Commit e Redireciona
                $pdo->commit();
                header("Location: clientes.php?view=form&id=$cliente_id&msg=criado");
                exit;

            } else {
                $cliente_id = $_POST['id'];
                $sql = "UPDATE clientes SET tipo_pessoa=?, cnpj_cpf=?, razao_social=?, nome_fantasia=?, cep=?, endereco_completo=?, bairro=?, cidade=?, uf=?, horario_funcionamento=?, segmento=?, po_responsavel=?, escopo_desc=? WHERE id=?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute(array_merge($dados_cliente, [$cliente_id]));
                
                // Salvar Fiscal (COM LIMPEZA DE NÚMEROS)
                $pdo->prepare("DELETE FROM clientes_fiscais WHERE cliente_id = ?")->execute([$cliente_id]);
                
                $sql_fiscal = "INSERT INTO clientes_fiscais (cliente_id, regime_tributario, cfop_padrao, icms_interno, icms_externo, pis_aliq, cofins_aliq, simples_aliq, usa_reforma, ibs_cbs_class, aliq_cbs, aliq_ibs_mun, aliq_ibs_uf) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                $pdo->prepare($sql_fiscal)->execute([
                    $cliente_id, 
                    $_POST['regime'], 
                    limparTexto($_POST['cfop_padrao']),
                    limparNum($_POST['icms_int']), 
                    limparNum($_POST['icms_ext']), 
                    limparNum($_POST['pis']), 
                    limparNum($_POST['cofins']), 
                    limparNum($_POST['simples']),
                    isset($_POST['usa_reforma']) ? 1 : 0, 
                    limparTexto($_POST['class_ibs']), 
                    limparNum($_POST['aliq_cbs']), 
                    limparNum($_POST['aliq_ibs_mun']), 
                    limparNum($_POST['aliq_ibs_uf'])
                ]);

                // Salvar Acesso Remoto
                $pdo->prepare("DELETE FROM clientes_acessos WHERE cliente_id = ?")->execute([$cliente_id]);
                if (!empty($_POST['soft_remoto'])) {
                    $pdo->prepare("INSERT INTO clientes_acessos (cliente_id, software, usuario_remoto, senha_remoto, codigo_acesso, computador_nome) VALUES (?, ?, ?, ?, ?, ?)")
                        ->execute([
                            $cliente_id, 
                            $_POST['soft_remoto'], 
                            $_POST['user_remoto'], 
                            $_POST['pass_remoto'], 
                            $_POST['id_remoto'], 
                            $_POST['pc_nome']
                        ]);
                }
                
                $msg = "Dados atualizados com sucesso!";
            }
        }

        // CASO 2: UPLOAD DE CERTIFICADO
        elseif ($acao == 'upload_cert') {
            $cliente_id = $_POST['id'];
            $senha_cert = $_POST['senha_certificado'];
            
            if (isset($_FILES['arquivo_cert']) && $_FILES['arquivo_cert']['error'] == 0) {
                if (!is_dir('uploads/certificados')) { mkdir('uploads/certificados', 0777, true); }

                $ext = pathinfo($_FILES['arquivo_cert']['name'], PATHINFO_EXTENSION);
                $novo_nome = "cert_" . $cliente_id . "_" . time() . "." . $ext;
                $destino = "uploads/certificados/" . $novo_nome;
                
                if (move_uploaded_file($_FILES['arquivo_cert']['tmp_name'], $destino)) {
                    $pdo->prepare("INSERT INTO clientes_certificados (cliente_id, arquivo_nome, caminho_arquivo, senha_winrar) VALUES (?, ?, ?, ?)")
                        ->execute([$cliente_id, $_FILES['arquivo_cert']['name'], $destino, $senha_cert]);
                    $msg = "Certificado anexado com sucesso!";
                } else {
                    $erro = "Falha ao mover arquivo. Verifique permissões.";
                }
            } else {
                $erro = "Selecione um arquivo válido.";
            }
        }

        // CASO 3: SALVAR PÓS-VENDA
        elseif ($acao == 'salvar_posvenda') {
            $cliente_id = $_POST['id'];
            $texto = $_POST['obs_posvenda'];
            if(!empty($texto)) {
                $pdo->prepare("INSERT INTO clientes_pos_venda (cliente_id, usuario_id, texto) VALUES (?, ?, ?)")
                    ->execute([$cliente_id, $_SESSION['user_id'], $texto]);
                $msg = "Histórico registrado!";
            }
        }

        $pdo->commit();

    } catch (Exception $e) {
        $pdo->rollBack();
        // Erro detalhado na tela para facilitar
        $erro = "ERRO AO SALVAR: " . $e->getMessage();
    }
}

// --- RECUPERAÇÃO DE DADOS ---
$cliente = null;
$fiscal = null;
$acesso = null;
$certificados = [];
$pos_vendas = [];
$ocorrencias = [];

if ($view == 'form' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $cliente = $pdo->query("SELECT * FROM clientes WHERE id = $id")->fetch();
    if($cliente) {
        $fiscal = $pdo->query("SELECT * FROM clientes_fiscais WHERE cliente_id = $id")->fetch();
        $acesso = $pdo->query("SELECT * FROM clientes_acessos WHERE cliente_id = $id")->fetch();
        $certificados = $pdo->query("SELECT * FROM clientes_certificados WHERE cliente_id = $id ORDER BY id DESC")->fetchAll();
        $pos_vendas = $pdo->query("SELECT pv.*, u.nome as usuario FROM clientes_pos_venda pv JOIN usuarios u ON pv.usuario_id = u.id WHERE pv.cliente_id = $id ORDER BY pv.data_registro DESC")->fetchAll();
        $ocorrencias = $pdo->query("SELECT * FROM ocorrencias WHERE cliente_id = $id ORDER BY id DESC")->fetchAll();
    }
}

if(isset($_GET['msg']) && $_GET['msg']=='criado') $msg = "Cliente criado! Continue preenchendo as abas.";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Clientes - Suindara v2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css?v=3" rel="stylesheet">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        
        <?php if($view == 'lista'): ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="text-white">Gestão de Clientes</h3>
                <a href="?view=form" class="btn btn-info fw-bold" style="background: var(--neon-blue); border:none; color:black;">+ Novo Cliente</a>
            </div>
            
            <?php if($msg) echo "<div class='alert alert-success'>$msg</div>"; ?>

            <div class="card card-custom p-0 table-responsive">
                <table class="table table-dark table-hover mb-0">
                    <thead class="bg-secondary">
                        <tr>
                            <th class="ps-4">Empresa</th>
                            <th>CNPJ/CPF</th>
                            <th>Cidade</th>
                            <th>Contato</th>
                            <th class="text-end pe-4">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $lista = $pdo->query("SELECT * FROM clientes ORDER BY id DESC LIMIT 50")->fetchAll();
                        foreach($lista as $c): 
                        ?>
                        <tr>
                            <td class="ps-4">
                                <strong class="text-info"><?= $c['nome_fantasia'] ?: $c['razao_social'] ?></strong>
                            </td>
                            <td><?= $c['cnpj_cpf'] ?></td>
                            <td><?= $c['cidade'] ?>/<?= $c['uf'] ?></td>
                            <td><?= $c['po_responsavel'] ?></td>
                            <td class="text-end pe-4">
                                <a href="?view=form&id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-info">Abrir Ficha</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php else: ?>
            <div class="d-flex justify-content-between mb-3 align-items-center">
                <div>
                    <h3 class="text-white m-0"><?= $cliente ? $cliente['nome_fantasia'] : 'Novo Cliente' ?></h3>
                    <small class="text-muted"><?= $cliente ? $cliente['razao_social'] : 'Preencha os dados iniciais' ?></small>
                </div>
                <a href="?view=lista" class="btn btn-outline-secondary">Voltar para Lista</a>
            </div>

            <?php if($msg) echo "<div class='alert alert-success'>$msg</div>"; ?>
            <?php if($erro) echo "<div class='alert alert-danger'>$erro</div>"; ?>

            <form method="POST" enctype="multipart/form-data" novalidate>
                <input type="hidden" name="id" value="<?= $cliente ? $cliente['id'] : 'novo' ?>">
                
                <ul class="nav nav-tabs" id="clientTab" role="tablist">
                    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#geral" type="button">📋 Geral</button></li>
                    <?php if($cliente): ?>
                        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#fiscal" type="button">⚖️ Fiscal</button></li>
                        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#remoto" type="button">💻 Acesso Remoto</button></li>
                        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#certificados" type="button">🔐 Certificado Digital</button></li>
                        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#produtos" type="button">📦 Produtos</button></li>
                        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#posvenda" type="button">💬 Pós-Venda</button></li>
                        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#ocorrencias" type="button">🔔 Ocorrências</button></li>
                    <?php else: ?>
                        <li class="nav-item"><button class="nav-link disabled">Salva o Geral Primeiro ➡️</button></li>
                    <?php endif; ?>
                </ul>

                <div class="tab-content">
                    
                    <div class="tab-pane fade show active" id="geral">
                        <div class="row g-3">
                            <div class="col-md-3">
                                <label>Tipo</label>
                                <select name="tipo_pessoa" class="form-select">
                                    <option value="J" <?= ($cliente['tipo_pessoa']??'')=='J'?'selected':'' ?>>Pessoa Jurídica</option>
                                    <option value="F" <?= ($cliente['tipo_pessoa']??'')=='F'?'selected':'' ?>>Pessoa Física</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label>CNPJ / CPF</label>
                                <div class="input-group">
                                    <input type="text" name="cnpj_cpf" id="cnpj" class="form-control" value="<?= $cliente['cnpj_cpf']??'' ?>">
                                    <button type="button" class="btn btn-outline-info" onclick="buscarCNPJ()">🔍</button>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <label>Razão Social *</label>
                                <input type="text" name="razao_social" id="razao" class="form-control" required value="<?= $cliente['razao_social']??'' ?>">
                            </div>
                            <div class="col-md-6">
                                <label>Nome Fantasia</label>
                                <input type="text" name="nome_fantasia" id="fantasia" class="form-control" value="<?= $cliente['nome_fantasia']??'' ?>">
                            </div>
                            <div class="col-md-6">
                                <label>Segmento</label>
                                <input type="text" name="segmento" class="form-control" value="<?= $cliente['segmento']??'' ?>">
                            </div>
                            <div class="col-12"><hr class="border-secondary"></div>
                            <div class="col-md-2">
                                <label>CEP</label>
                                <input type="text" name="cep" id="cep" class="form-control" onblur="buscarCEP()" value="<?= $cliente['cep']??'' ?>">
                            </div>
                            <div class="col-md-5">
                                <label>Endereço</label>
                                <input type="text" name="endereco" id="endereco" class="form-control" value="<?= $cliente['endereco_completo']??'' ?>">
                            </div>
                            <div class="col-md-3">
                                <label>Bairro</label>
                                <input type="text" name="bairro" id="bairro" class="form-control" value="<?= $cliente['bairro']??'' ?>">
                            </div>
                            <div class="col-md-2">
                                <label>Cidade / UF</label>
                                <div class="d-flex gap-1">
                                    <input type="text" name="cidade" id="cidade" class="form-control" value="<?= $cliente['cidade']??'' ?>">
                                    <input type="text" name="uf" id="uf" class="form-control" style="width:60px;" value="<?= $cliente['uf']??'' ?>">
                                </div>
                            </div>
                            <div class="col-12"><hr class="border-secondary"></div>
                            <div class="col-md-4"><label>Horário</label><input type="text" name="horario" class="form-control" value="<?= $cliente['horario_funcionamento']??'' ?>"></div>
                            <div class="col-md-4"><label>PO Resp.</label><input type="text" name="po_resp" class="form-control" value="<?= $cliente['po_responsavel']??'' ?>"></div>
                            <div class="col-md-12"><label>Escopo</label><textarea name="escopo" rows="3" class="form-control"><?= $cliente['escopo_desc']??'' ?></textarea></div>
                        </div>
                        
                        <div class="d-flex justify-content-end mt-4">
                            <button type="submit" name="acao_form" value="salvar_dados" class="btn btn-success fw-bold px-5">SALVAR DADOS GERAIS</button>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="fiscal">
                        <div class="row">
                            <div class="col-md-6 border-end border-secondary">
                                <h5 class="text-info mb-3">Regime Tradicional</h5>
                                <div class="mb-3">
                                    <label>Regime Tributário</label>
                                    <select name="regime" class="form-select">
                                        <option value="Simples" <?= ($fiscal['regime_tributario']??'')=='Simples'?'selected':'' ?>>Simples Nacional</option>
                                        <option value="Normal" <?= ($fiscal['regime_tributario']??'')=='Normal'?'selected':'' ?>>Normal / Lucro</option>
                                    </select>
                                </div>
                                <div class="mb-3"><label>CFOP Padrão</label><input type="text" name="cfop_padrao" class="form-control" value="<?= $fiscal['cfop_padrao']??'' ?>"></div>
                                <div class="row g-2">
                                    <div class="col-6"><label>ICMS Int %</label><input type="text" name="icms_int" class="form-control" value="<?= $fiscal['icms_interno']??'' ?>"></div>
                                    <div class="col-6"><label>ICMS Ext %</label><input type="text" name="icms_ext" class="form-control" value="<?= $fiscal['icms_externo']??'' ?>"></div>
                                    <div class="col-6"><label>PIS %</label><input type="text" name="pis" class="form-control" value="<?= $fiscal['pis_aliq']??'' ?>"></div>
                                    <div class="col-6"><label>COFINS %</label><input type="text" name="cofins" class="form-control" value="<?= $fiscal['cofins_aliq']??'' ?>"></div>
                                </div>
                            </div>
                            <div class="col-md-6 ps-4">
                                <h5 class="text-warning mb-3">Reforma Tributária</h5>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" name="usa_reforma" id="checkRef" <?= ($fiscal['usa_reforma']??0)==1?'checked':'' ?>>
                                    <label class="form-check-label" for="checkRef">Ativar Reforma Tributária</label>
                                </div>
                                <div class="mb-3"><label>Classificação IBS/CBS</label><input type="text" name="class_ibs" class="form-control" value="<?= $fiscal['ibs_cbs_class']??'' ?>"></div>
                                <div class="row g-2">
                                    <div class="col-4"><label>Aliq. CBS</label><input type="text" name="aliq_cbs" class="form-control" value="<?= $fiscal['aliq_cbs']??'' ?>"></div>
                                    <div class="col-4"><label>IBS Mun.</label><input type="text" name="aliq_ibs_mun" class="form-control" value="<?= $fiscal['aliq_ibs_mun']??'' ?>"></div>
                                    <div class="col-4"><label>IBS UF</label><input type="text" name="aliq_ibs_uf" class="form-control" value="<?= $fiscal['aliq_ibs_uf']??'' ?>"></div>
                                </div>
                            </div>
                        </div>
                        <div class="mt-4 text-end"><button type="submit" name="acao_form" value="salvar_dados" class="btn btn-success">Salvar Fiscal</button></div>
                    </div>

                    <div class="tab-pane fade" id="remoto">
                        <div class="row g-3">
                            <div class="col-md-4"><label>Software</label><input type="text" name="soft_remoto" class="form-control" value="<?= $acesso['software']??'' ?>"></div>
                            <div class="col-md-4"><label>ID / Acesso</label><input type="text" name="id_remoto" class="form-control" value="<?= $acesso['codigo_acesso']??'' ?>"></div>
                            <div class="col-md-4"><label>Nome PC</label><input type="text" name="pc_nome" class="form-control" value="<?= $acesso['computador_nome']??'' ?>"></div>
                            <div class="col-md-6"><label>Usuário Remoto</label><input type="text" name="user_remoto" class="form-control" value="<?= $acesso['usuario_remoto']??'' ?>"></div>
                            <div class="col-md-6"><label>Senha Remota</label><input type="text" name="pass_remoto" class="form-control" value="<?= $acesso['senha_remoto']??'' ?>"></div>
                        </div>
                        <div class="mt-4 text-end"><button type="submit" name="acao_form" value="salvar_dados" class="btn btn-success">Salvar Acesso Remoto</button></div>
                    </div>

                    <div class="tab-pane fade" id="certificados">
                        <div class="row g-3 align-items-end mb-4 border-bottom border-secondary pb-4">
                            <div class="col-md-5">
                                <label>Arquivo (WinRAR/ZIP)</label>
                                <input type="file" name="arquivo_cert" class="form-control">
                            </div>
                            <div class="col-md-4">
                                <label>Senha do Arquivo</label>
                                <input type="text" name="senha_certificado" class="form-control" placeholder="Senha...">
                            </div>
                            <div class="col-md-3">
                                <button type="submit" name="acao_form" value="upload_cert" class="btn btn-primary w-100">⬆️ Enviar Arquivo</button>
                            </div>
                        </div>

                        <h5 class="text-white">Arquivos Anexados</h5>
                        <table class="table table-dark table-sm mt-3">
                            <thead><tr><th>Nome</th><th>Data</th><th>Senha</th><th>Ação</th></tr></thead>
                            <tbody>
                                <?php foreach($certificados as $cert): ?>
                                <tr>
                                    <td><?= $cert['arquivo_nome'] ?></td>
                                    <td><?= date('d/m/Y H:i', strtotime($cert['data_upload'])) ?></td>
                                    <td class="text-info"><?= $cert['senha_winrar'] ?></td>
                                    <td><a href="<?= $cert['caminho_arquivo'] ?>" target="_blank" class="btn btn-sm btn-outline-light">Baixar</a></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="tab-pane fade" id="produtos">
                        <div class="alert alert-dark border-secondary">
                            <small>Histórico de produtos adquiridos (automático via Pedidos).</small>
                        </div>
                        <p class="text-muted text-center">Integração com Pedidos em breve.</p>
                    </div>

                    <div class="tab-pane fade" id="posvenda">
                        <div class="mb-4">
                            <label>Nova Anotação</label>
                            <div class="input-group">
                                <textarea name="obs_posvenda" class="form-control" rows="2"></textarea>
                                <button type="submit" name="acao_form" value="salvar_posvenda" class="btn btn-info">Registrar</button>
                            </div>
                        </div>
                        <div class="list-group">
                            <?php foreach($pos_vendas as $pv): ?>
                            <div class="list-group-item bg-dark text-white border-secondary mb-2">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1 text-info"><?= $pv['usuario'] ?></h6>
                                    <small><?= date('d/m/Y H:i', strtotime($pv['data_registro'])) ?></small>
                                </div>
                                <p class="mb-1 text-muted"><?= nl2br($pv['texto']) ?></p>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="ocorrencias">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="text-white">Histórico</h5>
                            <a href="ocorrencias.php?cliente_id=<?= $cliente['id'] ?>" class="btn btn-sm btn-outline-warning">Abrir Ocorrência</a>
                        </div>
                        <table class="table table-dark table-hover">
                            <thead><tr><th>#ID</th><th>Assunto</th><th>Status</th><th>Data</th></tr></thead>
                            <tbody>
                                <?php foreach($ocorrencias as $oco): ?>
                                <tr>
                                    <td>#<?= $oco['id'] ?></td>
                                    <td><?= $oco['assunto'] ?></td>
                                    <td><?= $oco['status'] ?></td>
                                    <td><?= date('d/m/Y', strtotime($oco['data_abertura'])) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                </div> </form> <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function buscarCEP() {
            let cep = document.getElementById('cep').value.replace(/\D/g, '');
            if (cep.length === 8) {
                fetch(`https://viacep.com.br/ws/${cep}/json/`).then(r => r.json()).then(d => {
                    if(!d.erro) {
                        document.getElementById('endereco').value = d.logradouro;
                        document.getElementById('bairro').value = d.bairro;
                        document.getElementById('cidade').value = d.localidade;
                        document.getElementById('uf').value = d.uf;
                    }
                });
            }
        }
        function buscarCNPJ() {
            let cnpj = document.getElementById('cnpj').value.replace(/\D/g, '');
            if(cnpj.length === 14) {
                fetch(`https://brasilapi.com.br/api/cnpj/v1/${cnpj}`).then(r => r.json()).then(d => {
                    document.getElementById('razao').value = d.razao_social;
                    document.getElementById('fantasia').value = d.nome_fantasia || d.razao_social;
                    if(d.cep) {
                        document.getElementById('cep').value = d.cep;
                        buscarCEP(); // Preenche o resto
                    }
                }).catch(() => alert('CNPJ não encontrado ou erro na API.'));
            }
        }
    </script>
</body>
</html>