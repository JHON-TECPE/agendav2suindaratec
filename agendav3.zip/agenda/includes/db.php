<?php
// Arquivo: includes/db.php

// Configurações do Banco baseadas nas suas imagens
$host = 'localhost';
$db   = 'hg86d858_suindara_v2'; 
$user = 'hg86d858_DBA'; 
$pass = 'Sfc@TS2025#*@'; 
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // Em caso de erro, mata o processo e mostra msg
    die("Erro Crítico de Conexão: " . $e->getMessage());
}
?>