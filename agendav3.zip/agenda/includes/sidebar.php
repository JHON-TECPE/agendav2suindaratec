<div class="sidebar" id="sidebar">
    <div class="brand">Suindara TEC</div>
    
    <a href="index.php" class="<?= basename($_SERVER['PHP_SELF'])=='index.php'?'active':'' ?>">
        📊 Dashboard
    </a>
    
    <a href="chat_interno.php" class="<?= basename($_SERVER['PHP_SELF'])=='chat_interno.php'?'active':'' ?>">
        💬 Chat Equipe
    </a>

    <a href="ocorrencias.php" class="<?= basename($_SERVER['PHP_SELF'])=='ocorrencias.php'?'active':'' ?>">
        🔔 Ocorrências
    </a>

    <a href="agenda.php" class="<?= basename($_SERVER['PHP_SELF'])=='agenda.php'?'active':'' ?>">
        📅 Agenda Operação
    </a>

    <a href="kanban.php" class="<?= basename($_SERVER['PHP_SELF'])=='kanban.php'?'active':'' ?>">
        🚀 Fluxo Comercial
    </a>

    <a href="#menuCadastros" data-bs-toggle="collapse" class="d-flex justify-content-between align-items-center">
        <span>📂 Cadastros</span> <small>▼</small>
    </a>
    <div class="collapse submenu" id="menuCadastros">
        <a href="clientes.php">• Clientes</a>
        <a href="colaboradores.php">• Colaboradores</a>
        <a href="produtos.php">• Produtos/Serviços</a>
    </div>

    <a href="#menuFin" data-bs-toggle="collapse" class="d-flex justify-content-between align-items-center">
        <span>💰 Financeiro</span> <small>▼</small>
    </a>
    <div class="collapse submenu" id="menuFin">
        <a href="orcamentos.php">• Orçamentos</a>
        <a href="pedidos.php">• Pedidos (Vendas)</a>
        <a href="contas_pagar.php" class="text-danger">• Contas a Pagar</a>
        <a href="contas_receber.php" class="text-success">• Contas a Receber</a>
    </div>

    <div class="mt-5 pt-3 border-top border-secondary mx-3">
        <small class="text-muted">Logado como:</small><br>
        <span class="text-white"><?= $_SESSION['user_nome'] ?? 'Admin' ?></span>
        <a href="logout.php" class="text-danger mt-2 ps-0" style="font-size: 0.9rem;">🚪 Sair do Sistema</a>
    </div>
</div>