<?php
// Arquivo: contas_pagar.php
require 'includes/auth.php';
require 'includes/db.php';

$msg = '';

// --- LÓGICA DE CADASTRO E BAIXA ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // 1. Nova Conta (Mantido igual)
    if (isset($_POST['nova_conta'])) {
        $descricao_base = $_POST['descricao'];
        $valor_total = (float) str_replace(',', '.', $_POST['valor']);
        $parcelas = (int) $_POST['parcelas'];
        $vencimento_inicial = $_POST['vencimento'];
        $categoria = $_POST['categoria'];
        $obs = $_POST['obs'];

        if ($parcelas < 1) $parcelas = 1;
        $valor_parcela = $valor_total / $parcelas;
        $sql = "INSERT INTO fin_lancamentos (tipo, descricao, valor, data_vencimento, categoria, observacoes) VALUES ('despesa', ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);

        for ($i = 0; $i < $parcelas; $i++) {
            $vencimento_atual = date('Y-m-d', strtotime("+$i month", strtotime($vencimento_inicial)));
            $descricao_final = $descricao_base . ($parcelas > 1 ? " (" . ($i + 1) . "/$parcelas)" : "");
            $stmt->execute([$descricao_final, $valor_parcela, $vencimento_atual, $categoria, $obs]);
        }
        $msg = "Despesa lançada com sucesso!";
    }

    // 2. BAIXA INTELIGENTE (Pagamento Total ou Parcial)
    elseif (isset($_POST['confirmar_baixa'])) {
        $id = $_POST['id_baixa'];
        $valor_pago = (float) str_replace(',', '.', $_POST['valor_pago']);
        
        // Busca a conta original para ver o valor total dela
        $stmt = $pdo->prepare("SELECT * FROM fin_lancamentos WHERE id = ?");
        $stmt->execute([$id]);
        $conta = $stmt->fetch();

        if ($conta) {
            $valor_original = (float) $conta['valor'];

            // Lógica de Diferença
            if ($valor_pago < $valor_original) {
                // PAGAMENTO PARCIAL
                $restante = $valor_original - $valor_pago;

                // 1. Atualiza a conta original para o valor que foi pago e fecha ela
                $pdo->prepare("UPDATE fin_lancamentos SET status='pago', valor=?, data_pagamento=NOW(), observacoes=CONCAT(observacoes, ' [Pago Parcial]') WHERE id=?")
                    ->execute([$valor_pago, $id]);

                // 2. Cria nova conta com o restante
                $sql_restante = "INSERT INTO fin_lancamentos (tipo, descricao, valor, data_vencimento, categoria, observacoes, status) VALUES (?, ?, ?, ?, ?, ?, 'pendente')";
                $pdo->prepare($sql_restante)->execute([
                    'despesa',
                    $conta['descricao'] . " (Restante)",
                    $restante,
                    $conta['data_vencimento'], // Mantém mesmo vencimento ou pode jogar pro próximo mês
                    $conta['categoria'],
                    "Saldo restante do pagamento parcial.",
                ]);

                $msg = "Pagamento parcial de R$ $valor_pago registrado! Nova pendência de R$ $restante criada.";
            } else {
                // PAGAMENTO TOTAL (Ou maior)
                $pdo->prepare("UPDATE fin_lancamentos SET status='pago', valor=?, data_pagamento=NOW() WHERE id=?")
                    ->execute([$valor_pago, $id]);
                $msg = "Conta quitada com sucesso!";
            }
        }
    }

    // 3. Excluir
    elseif (isset($_POST['excluir_conta'])) {
        $pdo->prepare("DELETE FROM fin_lancamentos WHERE id=?")->execute([$_POST['id']]);
        $msg = "Registro excluído.";
    }
}

// --- FILTROS ---
$filtro_inicio = $_GET['inicio'] ?? '';
$filtro_fim = $_GET['fim'] ?? '';
$filtro_texto = $_GET['texto'] ?? '';
$filtro_status = $_GET['status'] ?? '';

$sql_busca = "SELECT * FROM fin_lancamentos WHERE tipo='despesa'";
$params = [];

if($filtro_inicio) { $sql_busca .= " AND data_vencimento >= ?"; $params[] = $filtro_inicio; }
if($filtro_fim) { $sql_busca .= " AND data_vencimento <= ?"; $params[] = $filtro_fim; }
if($filtro_texto) { $sql_busca .= " AND descricao LIKE ?"; $params[] = "%$filtro_texto%"; }
if($filtro_status) { $sql_busca .= " AND status = ?"; $params[] = $filtro_status; }

$sql_busca .= " ORDER BY data_vencimento ASC";
$stmt = $pdo->prepare($sql_busca);
$stmt->execute($params);
$contas = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Contas a Pagar - Suindara v2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css?v=3" rel="stylesheet">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <h3 class="text-white mb-4">🔻 Contas a Pagar (Despesas)</h3>
        <?php if($msg) echo "<div class='alert alert-info'>$msg</div>"; ?>

        <div class="row">
            <div class="col-md-4">
                <div class="card card-custom p-3 border-danger mb-4">
                    <h5 class="text-danger">Nova Despesa</h5>
                    <form method="POST">
                        <input type="hidden" name="nova_conta" value="1">
                        <div class="mb-3"><label>Descrição</label><input type="text" name="descricao" class="form-control" required placeholder="Ex: Conta de Luz"></div>
                        <div class="row">
                            <div class="col-7 mb-3"><label>Valor Total</label><input type="number" step="0.01" name="valor" class="form-control" required></div>
                            <div class="col-5 mb-3"><label>Parcelas</label><input type="number" min="1" value="1" name="parcelas" class="form-control text-center" required></div>
                        </div>
                        <div class="mb-3"><label>1º Vencimento</label><input type="date" name="vencimento" class="form-control" required></div>
                        <div class="mb-3"><label>Categoria</label>
                            <select name="categoria" class="form-select">
                                <option>Operacional</option><option>Infraestrutura</option><option>Pessoal</option><option>Impostos</option><option>Fornecedores</option>
                            </select>
                        </div>
                        <div class="mb-3"><label>Obs</label><input type="text" name="obs" class="form-control"></div>
                        <button class="btn btn-danger w-100 fw-bold">LANÇAR DESPESA</button>
                    </form>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card card-custom p-3 mb-3">
                    <form method="GET" class="row g-2 align-items-end">
                        <div class="col-md-3"><label class="small text-muted">Data Inicial</label><input type="date" name="inicio" class="form-control form-control-sm" value="<?= $filtro_inicio ?>"></div>
                        <div class="col-md-3"><label class="small text-muted">Data Final</label><input type="date" name="fim" class="form-control form-control-sm" value="<?= $filtro_fim ?>"></div>
                        <div class="col-md-3"><label class="small text-muted">Status</label>
                            <select name="status" class="form-select form-select-sm">
                                <option value="">Todos</option><option value="pendente" <?= $filtro_status=='pendente'?'selected':'' ?>>Pendentes</option><option value="pago" <?= $filtro_status=='pago'?'selected':'' ?>>Pagos</option>
                            </select>
                        </div>
                        <div class="col-md-3"><label class="small text-muted">Busca</label><input type="text" name="texto" class="form-control form-control-sm" placeholder="Nome/Descrição..." value="<?= $filtro_texto ?>"></div>
                        <div class="col-md-12 text-end mt-2"><a href="contas_pagar.php" class="btn btn-sm btn-outline-secondary">Limpar</a> <button type="submit" class="btn btn-sm btn-info fw-bold">Filtrar</button></div>
                    </form>
                </div>

                <div class="card card-custom p-0 table-responsive">
                    <table class="table table-dark table-hover mb-0">
                        <thead><tr><th>Desc.</th><th>Valor</th><th>Vencimento</th><th>Status</th><th>Ação</th></tr></thead>
                        <tbody>
                            <?php foreach($contas as $c): 
                                $atrasado = ($c['status']=='pendente' && $c['data_vencimento'] < date('Y-m-d')) ? 'text-danger fw-bold' : '';
                            ?>
                            <tr>
                                <td><?= $c['descricao'] ?><br><small class="text-muted"><?= $c['categoria'] ?></small></td>
                                <td class="text-danger fw-bold">R$ <?= number_format($c['valor'], 2, ',', '.') ?></td>
                                <td class="<?= $atrasado ?>"><?= date('d/m/Y', strtotime($c['data_vencimento'])) ?></td>
                                <td>
                                    <?php if($c['status']=='pago'): ?>
                                        <span class="badge bg-success">PAGO</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark">PENDENTE</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($c['status']!='pago'): ?>
                                        <button class="btn btn-sm btn-outline-success" onclick="abrirModalBaixa(<?= $c['id'] ?>, '<?= $c['descricao'] ?>', <?= $c['valor'] ?>)">✅</button>
                                    <?php endif; ?>
                                    <form method="POST" class="d-inline" onsubmit="return confirm('Excluir?');">
                                        <input type="hidden" name="excluir_conta" value="1">
                                        <input type="hidden" name="id" value="<?= $c['id'] ?>">
                                        <button class="btn btn-sm btn-outline-danger">🗑️</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modalBaixa" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content bg-dark border-secondary">
                <div class="modal-header">
                    <h5 class="modal-title text-white">Baixar Conta</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="confirmar_baixa" value="1">
                        <input type="hidden" name="id_baixa" id="id_baixa">
                        
                        <p class="text-white">Conta: <strong id="nome_conta" class="text-info"></strong></p>
                        
                        <label class="text-white mb-2">Qual valor está sendo pago?</label>
                        <input type="number" step="0.01" name="valor_pago" id="valor_baixa" class="form-control form-control-lg text-center fw-bold" required>
                        
                        <div class="alert alert-secondary mt-3 small">
                            <span class="text-warning">⚠ Atenção:</span> Se você informar um valor menor que o total, o sistema baixará esta conta e criará uma nova pendência com a diferença automaticamente.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success w-100 fw-bold">CONFIRMAR PAGAMENTO</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function abrirModalBaixa(id, nome, valor) {
            document.getElementById('id_baixa').value = id;
            document.getElementById('nome_conta').innerText = nome;
            document.getElementById('valor_baixa').value = valor; // Sugere o valor total
            var modal = new bootstrap.Modal(document.getElementById('modalBaixa'));
            modal.show();
        }
    </script>
</body>
</html>