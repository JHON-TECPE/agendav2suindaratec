<?php
// Arquivo: api_eventos.php
require 'includes/auth.php';
require 'includes/db.php';

header('Content-Type: application/json');

$eventos = [];

// 1. Busca eventos manuais da tabela agenda_eventos
$sql_agenda = "SELECT a.*, c.nome_fantasia, u.nome as tecnico 
               FROM agenda_eventos a 
               JOIN clientes c ON a.cliente_id = c.id 
               JOIN usuarios u ON a.colaborador_id = u.id";
$res_agenda = $pdo->query($sql_agenda)->fetchAll();

foreach($res_agenda as $r) {
    $eventos[] = [
        'id' => 'evt_' . $r['id'],
        'title' => $r['titulo'] . ' (' . $r['nome_fantasia'] . ')',
        'start' => $r['inicio'],
        'end' => $r['fim'],
        'color' => $r['cor'],
        'description' => 'Técnico: ' . $r['tecnico']
    ];
}

// 2. Busca Ocorrências que têm 'data_retorno' definida
$sql_oco = "SELECT o.id, o.assunto, o.data_retorno, c.nome_fantasia 
            FROM ocorrencias o 
            JOIN clientes c ON o.cliente_id = c.id 
            WHERE o.data_retorno IS NOT NULL AND o.status != 'Concluido'";
$res_oco = $pdo->query($sql_oco)->fetchAll();

foreach($res_oco as $o) {
    // Cria um evento de 1 hora para o retorno
    $inicio = $o['data_retorno'];
    $fim = date('Y-m-d H:i:s', strtotime($inicio . ' +1 hour'));

    $eventos[] = [
        'id' => 'oco_' . $o['id'],
        'title' => 'RETORNO: ' . $o['assunto'] . ' - ' . $o['nome_fantasia'],
        'start' => $inicio,
        'end' => $fim,
        'color' => '#dc3545', // Vermelho para chamar atenção
        'url' => 'ocorrencias.php?id=' . $o['id'] // Clicar abre a ocorrência
    ];
}

echo json_encode($eventos);
?>