<?php
// Arquivo: relatorio_financeiro.php
require 'includes/auth.php';
require 'includes/db.php';

// Filtro de Mês e Ano (Padrão: Mês atual)
$mes = $_GET['mes'] ?? date('m');
$ano = $_GET['ano'] ?? date('Y');

// Array de meses para o select
$meses_nome = [
    '01'=>'Janeiro', '02'=>'Fevereiro', '03'=>'Março', '04'=>'Abril', '05'=>'Maio', '06'=>'Junho',
    '07'=>'Julho', '08'=>'Agosto', '09'=>'Setembro', '10'=>'Outubro', '11'=>'Novembro', '12'=>'Dezembro'
];

// --- CÁLCULOS DO BALANÇO ---
// 1. Receitas
$sql_rec = "SELECT SUM(valor) FROM fin_lancamentos WHERE tipo='receita' AND MONTH(data_vencimento) = ? AND YEAR(data_vencimento) = ?";
$stmt = $pdo->prepare($sql_rec);
$stmt->execute([$mes, $ano]);
$total_receitas = $stmt->fetchColumn() ?: 0;

// 2. Despesas
$sql_desp = "SELECT SUM(valor) FROM fin_lancamentos WHERE tipo='despesa' AND MONTH(data_vencimento) = ? AND YEAR(data_vencimento) = ?";
$stmt = $pdo->prepare($sql_desp);
$stmt->execute([$mes, $ano]);
$total_despesas = $stmt->fetchColumn() ?: 0;

// 3. Saldo
$saldo = $total_receitas - $total_despesas;

// --- LISTAGEM DETALHADA ---
$sql_lista = "SELECT * FROM fin_lancamentos 
              WHERE MONTH(data_vencimento) = ? AND YEAR(data_vencimento) = ? 
              ORDER BY data_vencimento ASC";
$stmt_lista = $pdo->prepare($sql_lista);
$stmt_lista->execute([$mes, $ano]);
$lancamentos = $stmt_lista->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Relatório Financeiro - Suindara v2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css?v=3" rel="stylesheet">
    <style>
        .card-resumo { border: 1px solid #333; background: #1e1e1e; border-radius: 8px; padding: 20px; text-align: center; }
        .texto-gigante { font-size: 2rem; font-weight: bold; }
    </style>
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="text-white">Fluxo de Caixa Mensal</h3>
            
            <form class="d-flex gap-2">
                <select name="mes" class="form-select bg-dark text-white border-secondary" style="width: 150px;">
                    <?php foreach($meses_nome as $num => $nome): ?>
                        <option value="<?= $num ?>" <?= $num==$mes?'selected':'' ?>><?= $nome ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="ano" class="form-select bg-dark text-white border-secondary" style="width: 100px;">
                    <?php for($i=2024; $i<=2030; $i++): ?>
                        <option value="<?= $i ?>" <?= $i==$ano?'selected':'' ?>><?= $i ?></option>
                    <?php endfor; ?>
                </select>
                <button class="btn btn-info fw-bold">Filtrar</button>
            </form>
        </div>

        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card-resumo border-bottom border-4 border-success">
                    <h5 class="text-success">Total Receitas</h5>
                    <div class="texto-gigante text-white">R$ <?= number_format($total_receitas, 2, ',', '.') ?></div>
                    <small class="text-muted">Entradas previstas/realizadas</small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card-resumo border-bottom border-4 border-danger">
                    <h5 class="text-danger">Total Despesas</h5>
                    <div class="texto-gigante text-white">R$ <?= number_format($total_despesas, 2, ',', '.') ?></div>
                    <small class="text-muted">Saídas previstas/realizadas</small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card-resumo border-bottom border-4 <?= $saldo >= 0 ? 'border-primary' : 'border-warning' ?>">
                    <h5 class="<?= $saldo >= 0 ? 'text-primary' : 'text-warning' ?>">Saldo do Mês</h5>
                    <div class="texto-gigante text-white">R$ <?= number_format($saldo, 2, ',', '.') ?></div>
                    <small class="text-muted">Lucro Operacional</small>
                </div>
            </div>
        </div>

        <div class="card card-custom p-0 table-responsive">
            <div class="p-3 border-bottom border-secondary">
                <h5 class="text-white m-0">Extrato de <?= $meses_nome[$mes] ?>/<?= $ano ?></h5>
            </div>
            <table class="table table-dark table-hover mb-0">
                <thead>
                    <tr>
                        <th>Vencimento</th>
                        <th>Descrição</th>
                        <th>Categoria</th>
                        <th>Tipo</th>
                        <th>Valor</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($lancamentos as $l): ?>
                    <tr>
                        <td><?= date('d/m/Y', strtotime($l['data_vencimento'])) ?></td>
                        <td><?= $l['descricao'] ?></td>
                        <td><?= $l['categoria'] ?></td>
                        <td>
                            <?php if($l['tipo'] == 'receita'): ?>
                                <span class="badge bg-success text-white">Receita ⬆</span>
                            <?php else: ?>
                                <span class="badge bg-danger text-white">Despesa ⬇</span>
                            <?php endif; ?>
                        </td>
                        <td class="fw-bold <?= $l['tipo']=='receita'?'text-success':'text-danger' ?>">
                            R$ <?= number_format($l['valor'], 2, ',', '.') ?>
                        </td>
                        <td>
                            <?php if($l['status'] == 'pago'): ?>
                                <span class="text-success">✔ Pago</span>
                            <?php else: ?>
                                <span class="text-warning">⏳ Pendente</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($lancamentos)) echo "<tr><td colspan='6' class='text-center p-3 text-muted'>Nenhum lançamento neste mês.</td></tr>"; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>