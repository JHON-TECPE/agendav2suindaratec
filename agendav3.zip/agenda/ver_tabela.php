<?php
require 'includes/db.php';

echo "<h2>🕵️ Raio-X da Tabela: agenda_eventos</h2>";

try {
    // Lista todas as colunas que o PHP consegue ver
    $stmt = $pdo->query("DESCRIBE agenda_eventos");
    $colunas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo "<table border='1' cellpadding='10' style='border-collapse: collapse; font-family: Arial;'>";
    echo "<tr style='background: #eee;'><th>Campo (Field)</th><th>Tipo</th></tr>";
    
    $tem_tecnico = false;
    foreach ($colunas as $c) {
        // Pinta de verde se achar a coluna tecnico_id
        $destaque = ($c['Field'] == 'tecnico_id') ? "style='background: #dff0d8; color: green; font-weight: bold;'" : "";
        if($c['Field'] == 'tecnico_id') $tem_tecnico = true;
        
        echo "<tr $destaque>";
        echo "<td>" . $c['Field'] . "</td>";
        echo "<td>" . $c['Type'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";

    echo "<br>";
    if ($tem_tecnico) {
        echo "<h3 style='color: green;'>✅ A coluna 'tecnico_id' EXISTE!</h3>";
        echo "<p>Se o erro continua, pode ser cache ou erro de digitação no código SQL.</p>";
    } else {
        echo "<h3 style='color: red;'>❌ A coluna 'tecnico_id' NÃO EXISTE para o site.</h3>";
        echo "<p>Verifique se você está editando o banco de dados correto no PHPMyAdmin.</p>";
        echo "<p>Banco conectado no site: <strong>" . $pdo->query('select database()')->fetchColumn() . "</strong></p>";
    }

} catch (Exception $e) {
    echo "Erro ao ler tabela: " . $e->getMessage();
}
?>