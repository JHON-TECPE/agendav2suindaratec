<?php
// Arquivo: orcamentos.php
require 'includes/auth.php';
require 'includes/db.php';

$view = isset($_GET['view']) ? $_GET['view'] : 'lista';
$msg = '';

// --- SALVAR ORÇAMENTO ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['acao'])) {
    try {
        $pdo->beginTransaction();

        $dados = [
            'orcamento', // Tipo fixo
            $_POST['cliente_id'],
            $_SESSION['user_id'], // Vendedor é quem está logado
            $_POST['data_emissao'],
            $_POST['validade'],
            $_POST['forma_pagamento'],
            $_POST['obs'],
            str_replace(',', '.', $_POST['valor_total']), // Total Geral
            'Aberto' // Status inicial
        ];

        if ($_POST['acao'] == 'novo') {
            $sql = "INSERT INTO pedidos_orcamentos (tipo, cliente_id, vendedor_id, data_emissao, validade_dias, forma_pagamento, observacoes, valor_total, status) VALUES (?,?,?,?,?,?,?,?,?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($dados);
            $pedido_id = $pdo->lastInsertId();
            $msg = "Orçamento #$pedido_id criado com sucesso!";
        } else {
            // Editar
            $pedido_id = $_POST['id'];
            $sql = "UPDATE pedidos_orcamentos SET cliente_id=?, data_emissao=?, validade_dias=?, forma_pagamento=?, observacoes=?, valor_total=? WHERE id=?";
            $pdo->prepare($sql)->execute([
                $_POST['cliente_id'], $_POST['data_emissao'], $_POST['validade'], 
                $_POST['forma_pagamento'], $_POST['obs'], 
                str_replace(',', '.', $_POST['valor_total']), $pedido_id
            ]);
            
            // Limpa itens antigos para recriar
            $pdo->prepare("DELETE FROM pedidos_itens WHERE pedido_id=?")->execute([$pedido_id]);
            $msg = "Orçamento atualizado!";
        }

        // Salvar Itens do Orçamento
        if (isset($_POST['produto_id'])) {
            $sql_item = "INSERT INTO pedidos_itens (pedido_id, produto_id, quantidade, valor_unitario, valor_total) VALUES (?,?,?,?,?)";
            $stmt_item = $pdo->prepare($sql_item);
            
            for ($i = 0; $i < count($_POST['produto_id']); $i++) {
                $prod_id = $_POST['produto_id'][$i];
                if(empty($prod_id)) continue;
                
                $qtd = str_replace(',', '.', $_POST['qtd'][$i]);
                $vlr = str_replace(',', '.', $_POST['preco'][$i]);
                $tot = $qtd * $vlr;
                
                $stmt_item->execute([$pedido_id, $prod_id, $qtd, $vlr, $tot]);
            }
        }

        $pdo->commit();
        $view = 'lista';

    } catch (Exception $e) {
        $pdo->rollBack();
        $msg = "Erro ao salvar: " . $e->getMessage();
    }
}

// --- CONVERTER EM PEDIDO ---
if (isset($_GET['aprovar'])) {
    $pdo->prepare("UPDATE pedidos_orcamentos SET tipo='pedido', status='Aprovado' WHERE id=?")->execute([$_GET['aprovar']]);
    header("Location: pedidos.php?msg=aprovado"); // Manda para tela de pedidos (vamos criar depois)
    exit;
}

// --- DADOS PARA O FORMULÁRIO ---
$clientes = $pdo->query("SELECT id, nome_fantasia, razao_social FROM clientes ORDER BY nome_fantasia")->fetchAll();
$produtos_db = $pdo->query("SELECT * FROM produtos ORDER BY nome")->fetchAll(); // Para o select de produtos

$orcamento = null;
$itens = [];

if (isset($_GET['id'])) {
    $orcamento = $pdo->prepare("SELECT * FROM pedidos_orcamentos WHERE id = ?");
    $orcamento->execute([$_GET['id']]);
    $orcamento = $orcamento->fetch();
    
    if($orcamento) {
        $itens = $pdo->query("SELECT * FROM pedidos_itens WHERE pedido_id = " . $orcamento['id'])->fetchAll();
        $view = 'form';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Orçamentos - Suindara v2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css?v=2" rel="stylesheet">
    <style>
        .table-itens input { background: transparent; border: none; color: white; width: 100%; }
        .table-itens input:focus { outline: 1px solid var(--neon-blue); }
        .remove-row { cursor: pointer; color: #ff4444; }
    </style>
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        
        <?php if($view == 'lista'): ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="text-white">Orçamentos Comerciais</h3>
                <a href="?view=form" class="btn btn-info fw-bold" style="background: var(--neon-blue); border:none; color:black;">+ Novo Orçamento</a>
            </div>

            <?php if($msg) echo "<div class='alert alert-info'>$msg</div>"; ?>

            <div class="card card-custom p-0 table-responsive">
                <table class="table table-dark table-hover mb-0">
                    <thead>
                        <tr>
                            <th>#ID</th>
                            <th>Cliente</th>
                            <th>Data</th>
                            <th>Valor Total</th>
                            <th>Status</th>
                            <th class="text-end">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $lista = $pdo->query("SELECT o.*, c.nome_fantasia FROM pedidos_orcamentos o JOIN clientes c ON o.cliente_id = c.id WHERE o.tipo='orcamento' ORDER BY o.id DESC")->fetchAll();
                        foreach($lista as $o): 
                        ?>
                        <tr>
                            <td>#<?= $o['id'] ?></td>
                            <td><?= $o['nome_fantasia'] ?></td>
                            <td><?= date('d/m/Y', strtotime($o['data_emissao'])) ?></td>
                            <td class="text-info fw-bold">R$ <?= number_format($o['valor_total'], 2, ',', '.') ?></td>
                            <td><?= $o['status'] ?></td>
                            <td class="text-end">
                                <a href="imprimir_orcamento.php?id=<?= $o['id'] ?>" target="_blank" class="btn btn-sm btn-outline-light" title="Imprimir PDF">🖨️</a>
                                <a href="?view=form&id=<?= $o['id'] ?>" class="btn btn-sm btn-outline-info" title="Editar">✏️</a>
                                <a href="?aprovar=<?= $o['id'] ?>" class="btn btn-sm btn-success" onclick="return confirm('Deseja converter este orçamento em PEDIDO FINAL?')" title="Aprovar/Vender">✅ Aprovar</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php else: ?>
            <form method="POST" id="formOrcamento">
                <input type="hidden" name="acao" value="<?= $orcamento ? 'editar' : 'novo' ?>">
                <?php if($orcamento): ?><input type="hidden" name="id" value="<?= $orcamento['id'] ?>"><?php endif; ?>
                
                <div class="d-flex justify-content-between mb-3">
                    <h3 class="text-white">Emitir Orçamento</h3>
                    <div>
                        <a href="orcamentos.php" class="btn btn-outline-secondary me-2">Cancelar</a>
                        <button type="submit" class="btn btn-success fw-bold">SALVAR ORÇAMENTO</button>
                    </div>
                </div>

                <div class="card card-custom p-4 mb-3">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label>Cliente</label>
                            <select name="cliente_id" class="form-select" required>
                                <option value="">Selecione...</option>
                                <?php foreach($clientes as $c): ?>
                                    <option value="<?= $c['id'] ?>" <?= ($orcamento['cliente_id']??'')==$c['id']?'selected':'' ?>><?= $c['nome_fantasia'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label>Data Emissão</label>
                            <input type="date" name="data_emissao" class="form-control" value="<?= $orcamento['data_emissao'] ?? date('Y-m-d') ?>">
                        </div>
                        <div class="col-md-3">
                            <label>Validade (Dias)</label>
                            <input type="number" name="validade" class="form-control" value="<?= $orcamento['validade_dias'] ?? '10' ?>">
                        </div>
                        <div class="col-md-6">
                            <label>Forma de Pagamento</label>
                            <input type="text" name="forma_pagamento" class="form-control" placeholder="Ex: 50% Entrada + 30 dias" value="<?= $orcamento['forma_pagamento']??'' ?>">
                        </div>
                        <div class="col-md-6">
                            <label>Observações</label>
                            <input type="text" name="obs" class="form-control" placeholder="Notas internas ou para o cliente..." value="<?= $orcamento['observacoes']??'' ?>">
                        </div>
                    </div>
                </div>

                <div class="card card-custom p-0">
                    <div class="p-3 border-bottom border-secondary d-flex justify-content-between align-items-center">
                        <h5 class="m-0 text-info">Itens do Orçamento</h5>
                        <button type="button" class="btn btn-sm btn-outline-info" onclick="addLinha()">+ Adicionar Item</button>
                    </div>
                    
                    <table class="table table-dark table-itens mb-0">
                        <thead>
                            <tr>
                                <th width="40%">Produto/Serviço</th>
                                <th width="15%">Qtd</th>
                                <th width="20%">Preço Un.</th>
                                <th width="20%">Total</th>
                                <th width="5%"></th>
                            </tr>
                        </thead>
                        <tbody id="tbody-itens">
                            <?php if($itens): foreach($itens as $it): ?>
                                <tr>
                                    <td>
                                        <select name="produto_id[]" class="form-control" onchange="buscarPreco(this)">
                                            <?php foreach($produtos_db as $p): ?>
                                                <option value="<?= $p['id'] ?>" data-preco="<?= $p['preco_venda'] ?>" <?= $p['id']==$it['produto_id']?'selected':'' ?>><?= $p['nome'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                    <td><input type="number" name="qtd[]" step="0.01" class="text-center" value="<?= $it['quantidade'] ?>" oninput="calcTotal(this)"></td>
                                    <td><input type="number" name="preco[]" step="0.01" class="text-end" value="<?= $it['valor_unitario'] ?>" oninput="calcTotal(this)"></td>
                                    <td><input type="text" readonly class="text-end fw-bold text-info total-linha" value="<?= $it['valor_total'] ?>"></td>
                                    <td class="text-center"><span class="remove-row" onclick="removeLinha(this)">✖</span></td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                        <tfoot>
                            <tr class="bg-secondary">
                                <td colspan="3" class="text-end fw-bold pe-3">TOTAL GERAL:</td>
                                <td><input type="text" name="valor_total" id="total_geral" class="form-control text-end fw-bold bg-transparent border-0 fs-5 text-white" readonly value="<?= $orcamento['valor_total']??'0.00' ?>"></td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

            </form>
        <?php endif; ?>
    </div>

    <div id="modelo-select" style="display:none;">
        <option value="">Selecione...</option>
        <?php foreach($produtos_db as $p): ?>
            <option value="<?= $p['id'] ?>" data-preco="<?= $p['preco_venda'] ?>"><?= $p['nome'] ?></option>
        <?php endforeach; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function addLinha() {
            let tbody = document.getElementById('tbody-itens');
            let options = document.getElementById('modelo-select').innerHTML;
            let tr = document.createElement('tr');
            tr.innerHTML = `
                <td><select name="produto_id[]" class="form-control bg-dark text-white border-0" onchange="buscarPreco(this)">${options}</select></td>
                <td><input type="number" name="qtd[]" value="1" step="0.01" class="text-center" oninput="calcTotal(this)"></td>
                <td><input type="number" name="preco[]" value="0.00" step="0.01" class="text-end" oninput="calcTotal(this)"></td>
                <td><input type="text" readonly class="text-end fw-bold text-info total-linha" value="0.00"></td>
                <td class="text-center"><span class="remove-row" onclick="removeLinha(this)">✖</span></td>
            `;
            tbody.appendChild(tr);
        }

        function removeLinha(btn) {
            btn.closest('tr').remove();
            calcGeral();
        }

        function buscarPreco(select) {
            let preco = select.options[select.selectedIndex].getAttribute('data-preco');
            let tr = select.closest('tr');
            tr.querySelector('input[name="preco[]"]').value = preco;
            calcTotal(select);
        }

        function calcTotal(element) {
            let tr = element.closest('tr');
            let qtd = parseFloat(tr.querySelector('input[name="qtd[]"]').value) || 0;
            let preco = parseFloat(tr.querySelector('input[name="preco[]"]').value) || 0;
            let total = qtd * preco;
            tr.querySelector('.total-linha').value = total.toFixed(2);
            calcGeral();
        }

        function calcGeral() {
            let total = 0;
            document.querySelectorAll('.total-linha').forEach(el => {
                total += parseFloat(el.value) || 0;
            });
            document.getElementById('total_geral').value = total.toFixed(2);
        }

        // Se estiver criando novo, já adiciona uma linha vazia
        <?php if(!$orcamento): ?>
        window.onload = function() { addLinha(); };
        <?php endif; ?>
    </script>
</body>
</html>