<?php
// Arquivo: imprimir_orcamento.php
require 'includes/auth.php';
require 'includes/db.php';

if (!isset($_GET['id'])) die("ID não informado");

$id = $_GET['id'];
$orc = $pdo->query("SELECT o.*, c.*, u.nome as vendedor_nome 
                    FROM pedidos_orcamentos o 
                    JOIN clientes c ON o.cliente_id = c.id 
                    JOIN usuarios u ON o.vendedor_id = u.id 
                    WHERE o.id = $id")->fetch();

$itens = $pdo->query("SELECT i.*, p.nome, p.unidade 
                      FROM pedidos_itens i 
                      JOIN produtos p ON i.produto_id = p.id 
                      WHERE i.pedido_id = $id")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Orçamento #<?= str_pad($orc['id'], 6, '0', STR_PAD_LEFT) ?></title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #000; background: #fff; margin: 0; padding: 40px; }
        
        /* Cabeçalho */
        .header { display: flex; align-items: center; border-bottom: 3px solid #000; padding-bottom: 20px; margin-bottom: 30px; }
        .logo-area { width: 120px; margin-right: 20px; }
        .logo-area img { width: 100%; height: auto; }
        
        .company-info { flex: 1; }
        .company-info h1 { margin: 0 0 5px 0; font-size: 24px; color: #000; text-transform: uppercase; }
        .company-info p { margin: 2px 0; font-size: 12px; color: #444; }

        .doc-info { width: 200px; text-align: right; border-left: 1px solid #ccc; padding-left: 20px; }
        .doc-title { font-size: 18px; font-weight: bold; color: #000; margin-bottom: 5px; }
        .doc-number { font-size: 22px; color: #d00; font-weight: bold; margin-bottom: 10px; }
        
        /* Caixas de Dados */
        .box { border: 1px solid #aaa; border-radius: 5px; padding: 10px; margin-bottom: 15px; background: #fdfdfd; }
        .box-title { font-weight: bold; font-size: 14px; margin-bottom: 8px; border-bottom: 1px solid #eee; padding-bottom: 3px; color: #000; text-transform: uppercase; }
        .row { display: flex; margin-bottom: 4px; }
        .col { flex: 1; }
        .label { font-weight: bold; color: #333; margin-right: 5px; }

        /* Tabela */
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th { background: #000; color: #fff; padding: 10px 8px; text-align: left; font-size: 12px; text-transform: uppercase; }
        td { border-bottom: 1px solid #ccc; padding: 8px; font-size: 12px; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .text-center { text-align: center; }
        .text-end { text-align: right; }

        /* Totais */
        .total-area { margin-top: 20px; display: flex; justify-content: flex-end; }
        .total-box { background: #eee; padding: 15px; border-radius: 5px; width: 250px; }
        .total-row { display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 14px; }
        .total-final { font-size: 18px; font-weight: bold; border-top: 1px solid #aaa; pt: 10px; margin-top: 5px; color: #000; }

        /* Rodapé */
        .footer { margin-top: 60px; text-align: center; border-top: 1px solid #ccc; padding-top: 15px; font-size: 11px; color: #666; }
        
        @media print {
            .no-print { display: none; }
            body { padding: 0; }
        }
    </style>
</head>
<body>

    <div class="no-print" style="position: fixed; top: 20px; right: 20px; background: #fff; padding: 10px; border: 1px solid #ccc; box-shadow: 0 0 10px rgba(0,0,0,0.1); border-radius: 5px;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #007bff; color: white; border: none; cursor: pointer; border-radius: 4px; font-weight: bold;">🖨️ IMPRIMIR / PDF</button>
        <button onclick="window.close()" style="padding: 10px 20px; background: #666; color: white; border: none; cursor: pointer; border-radius: 4px; margin-left: 10px;">FECHAR</button>
    </div>

    <div class="header">
        <div class="logo-area">
            <img src="assets/logo.jpg" alt="Logo Suindara"> 
        </div>
        <div class="company-info">
            <h1>Suindara TEC</h1>
            <p><strong>CNPJ:</strong> 70.301.361/0001-44</p>
            <p><strong>Endereço:</strong> Avenida Portugal, 1330 - Universitário, Caruaru - PE</p>
            <p><strong>Contato:</strong> (81) 99440-8620 | johnny.santos@suindaratec.com.br</p>
        </div>
        <div class="doc-info">
            <div class="doc-title"><?= strtoupper($orc['tipo']) ?></div>
            <div class="doc-number">Nº <?= str_pad($orc['id'], 6, '0', STR_PAD_LEFT) ?></div>
            <p>Emissão: <?= date('d/m/Y', strtotime($orc['data_emissao'])) ?></p>
        </div>
    </div>

    <div class="box">
        <div class="box-title">Dados do Cliente</div>
        <div class="row">
            <div class="col"><span class="label">Razão Social:</span> <?= $orc['razao_social'] ?></div>
            <div class="col"><span class="label">CNPJ/CPF:</span> <?= $orc['cnpj_cpf'] ?></div>
        </div>
        <div class="row">
            <div class="col"><span class="label">Endereço:</span> <?= $orc['endereco_completo'] ?>, <?= $orc['bairro'] ?> - <?= $orc['cidade'] ?>/<?= $orc['uf'] ?></div>
        </div>
        <div class="row">
            <div class="col"><span class="label">Contato:</span> <?= $orc['po_responsavel'] ?></div>
            <div class="col"><span class="label">Telefone:</span> (Ver cadastro)</div>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th width="5%" class="text-center">#</th>
                <th>Descrição do Produto / Serviço</th>
                <th width="10%" class="text-center">Unid.</th>
                <th width="10%" class="text-center">Qtd.</th>
                <th width="15%" class="text-end">Vlr. Unit.</th>
                <th width="15%" class="text-end">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $count=1; foreach($itens as $item): ?>
            <tr>
                <td class="text-center"><?= $count++ ?></td>
                <td><?= $item['nome'] ?></td>
                <td class="text-center"><?= $item['unidade'] ?></td>
                <td class="text-center"><?= number_format($item['quantidade'], 2, ',', '.') ?></td>
                <td class="text-end">R$ <?= number_format($item['valor_unitario'], 2, ',', '.') ?></td>
                <td class="text-end fw-bold">R$ <?= number_format($item['valor_total'], 2, ',', '.') ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div style="display: flex; justify-content: space-between; margin-top: 15px;">
        
        <div class="box" style="width: 55%; margin-bottom: 0;">
            <div class="box-title">Condições Comerciais</div>
            <p><span class="label">Forma de Pagamento:</span> <?= $orc['forma_pagamento'] ?: 'A combinar' ?></p>
            <p><span class="label">Validade da Proposta:</span> <?= $orc['validade_dias'] ?> dias</p>
            <p><span class="label">Vendedor:</span> <?= $orc['vendedor_nome'] ?></p>
            <?php if($orc['observacoes']): ?>
                <p style="margin-top: 10px; font-style: italic; color: #555;">"<?= $orc['observacoes'] ?>"</p>
            <?php endif; ?>
        </div>

        <div class="total-area">
            <div class="total-box">
                <div class="total-row">
                    <span>Subtotal:</span>
                    <span>R$ <?= number_format($orc['valor_total'], 2, ',', '.') ?></span>
                </div>
                <div class="total-row total-final">
                    <span>TOTAL A PAGAR:</span>
                    <span>R$ <?= number_format($orc['valor_total'], 2, ',', '.') ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="footer">
        <p>Este documento não vale como recibo de pagamento. A validade dos produtos está sujeita à disponibilidade de estoque.</p>
        <p>Sistema Suindara TEC - Gerado em <?= date('d/m/Y H:i') ?></p>
    </div>

</body>
</html>