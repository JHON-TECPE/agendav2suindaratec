<?php
// Arquivo: index.php
require 'includes/auth.php';
require 'includes/db.php';

// --- 1. DADOS DOS CARDS (MANTIDOS GLOBAIS) ---
$oco_abertas = $pdo->query("SELECT COUNT(*) FROM ocorrencias WHERE status = 'Aberto'")->fetchColumn();
$oco_andamento = $pdo->query("SELECT COUNT(*) FROM ocorrencias WHERE status = 'Em Andamento'")->fetchColumn();
$mes_atual = date('m');
$vendas_mes = $pdo->query("SELECT SUM(valor_total) FROM pedidos_orcamentos WHERE tipo = 'pedido' AND status != 'Cancelado' AND MONTH(data_emissao) = '$mes_atual'")->fetchColumn();
$hoje = date('Y-m-d');
$agenda_hoje = $pdo->query("SELECT COUNT(*) FROM agenda_eventos WHERE DATE(inicio) = '$hoje'")->fetchColumn();
$retornos_hoje = $pdo->query("SELECT COUNT(*) FROM ocorrencias WHERE DATE(data_retorno) = '$hoje' AND status != 'Concluido'")->fetchColumn();
$total_agenda = $agenda_hoje + $retornos_hoje;


// --- 2. LÓGICA DE FILTROS DA TABELA ---
$filtro_inicio = $_GET['inicio'] ?? '';
$filtro_fim = $_GET['fim'] ?? '';
$filtro_cliente = $_GET['cliente'] ?? '';
$filtro_status = $_GET['status'] ?? '';

// Query Base
$sql_tabela = "SELECT o.*, c.nome_fantasia 
               FROM ocorrencias o 
               JOIN clientes c ON o.cliente_id = c.id 
               WHERE 1=1"; 

$params = [];

if($filtro_inicio) {
    $sql_tabela .= " AND DATE(o.data_abertura) >= ?";
    $params[] = $filtro_inicio;
}
if($filtro_fim) {
    $sql_tabela .= " AND DATE(o.data_abertura) <= ?";
    $params[] = $filtro_fim;
}
if($filtro_cliente) {
    $sql_tabela .= " AND (c.nome_fantasia LIKE ? OR c.razao_social LIKE ?)";
    $params[] = "%$filtro_cliente%";
    $params[] = "%$filtro_cliente%";
}
if($filtro_status) {
    $sql_tabela .= " AND o.status = ?";
    $params[] = $filtro_status;
}

// Ordenação e Limite
$limite = (empty($_GET)) ? 10 : 50;
$sql_tabela .= " ORDER BY o.id DESC LIMIT $limite";

$stmt = $pdo->prepare($sql_tabela);
$stmt->execute($params);
$ultimas_oco = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Suindara v2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css?v=3" rel="stylesheet">
</head>
<body>

    <?php include 'includes/sidebar.php'; ?>

    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="text-white">Visão Geral</h2>
            <a href="ocorrencias.php?view=form" class="btn btn-info fw-bold" style="background: var(--neon-blue); border:none; color:black;">+ Nova Ocorrência</a>
        </div>

        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card-custom border-start border-4 border-danger">
                    <h5 class="text-muted">Chamados Abertos</h5>
                    <h2 class="text-white mt-2"><?= $oco_abertas ?></h2>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card-custom border-start border-4 border-warning">
                    <h5 class="text-muted">Em Atendimento</h5>
                    <h2 class="text-white mt-2"><?= $oco_andamento ?></h2>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card-custom border-start border-4 border-success">
                    <h5 class="text-muted">Vendas (Mês Atual)</h5>
                    <h2 class="text-white mt-2">R$ <?= number_format($vendas_mes ?: 0, 2, ',', '.') ?></h2>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card-custom border-start border-4 border-primary">
                    <h5 class="text-muted">Agenda Hoje</h5>
                    <h2 class="text-white mt-2"><?= $total_agenda ?></h2>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-9">
                
                <div class="card card-custom p-3 mb-3">
                    <form method="GET" class="row g-2 align-items-end">
                        <div class="col-md-2">
                            <label class="small text-muted">De:</label>
                            <input type="date" name="inicio" class="form-control form-control-sm" value="<?= $filtro_inicio ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="small text-muted">Até:</label>
                            <input type="date" name="fim" class="form-control form-control-sm" value="<?= $filtro_fim ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="small text-muted">Cliente:</label>
                            <input type="text" name="cliente" class="form-control form-control-sm" placeholder="Nome..." value="<?= $filtro_cliente ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="small text-muted">Status:</label>
                            <select name="status" class="form-select form-select-sm">
                                <option value="">Todas</option>
                                <option value="Aberto" <?= $filtro_status=='Aberto'?'selected':'' ?>>🔴 Abertas</option>
                                <option value="Em Andamento" <?= $filtro_status=='Em Andamento'?'selected':'' ?>>🟡 Em Andamento</option>
                                <option value="Concluido" <?= $filtro_status=='Concluido'?'selected':'' ?>>🟢 Concluídas</option>
                            </select>
                        </div>
                        <div class="col-md-2 d-grid">
                            <button type="submit" class="btn btn-sm btn-info fw-bold">Filtrar</button>
                        </div>
                    </form>
                </div>

                <div class="card card-custom p-0 table-responsive">
                    <div class="p-3 border-bottom border-secondary d-flex justify-content-between align-items-center">
                        <h5 class="m-0 text-white">Central de Chamados</h5>
                        <?php if(!empty($_GET)): ?>
                            <a href="index.php" class="btn btn-sm btn-outline-secondary">Limpar Filtros</a>
                        <?php endif; ?>
                    </div>
                    <table class="table table-dark table-hover mb-0 align-middle">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Cliente</th>
                                <th>Assunto</th>
                                <th>Status</th>
                                <th>Abertura</th>
                                <th>Prev. Fim</th>
                                <th class="text-end">Ação</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($ultimas_oco as $u): 
                                $badge = match($u['status']) { 
                                    'Aberto'=>'bg-danger', 
                                    'Em Andamento'=>'bg-warning text-dark', 
                                    'Concluido'=>'bg-success', 
                                    default=>'bg-secondary' 
                                };
                                $data_abertura = date('d/m/y H:i', strtotime($u['data_abertura']));
                                $data_retorno = $u['data_retorno'] ? date('d/m/y H:i', strtotime($u['data_retorno'])) : '<span class="text-muted small">-</span>';
                            ?>
                            <tr>
                                <td>#<?= $u['id'] ?></td>
                                <td><?= substr($u['nome_fantasia'], 0, 20) ?>...</td>
                                <td><?= $u['assunto'] ?></td>
                                <td><span class="badge <?= $badge ?>"><?= $u['status'] ?></span></td>
                                <td class="small"><?= $data_abertura ?></td>
                                <td class="small text-info"><?= $data_retorno ?></td>
                                <td class="text-end">
                                    <a href="ocorrencias.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-info">Abrir ➜</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(empty($ultimas_oco)) echo "<tr><td colspan='7' class='text-center text-muted p-3'>Nenhum registro encontrado.</td></tr>"; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card card-custom p-3">
                    <h5 class="text-info mb-3">Acesso Rápido</h5>
                    <div class="d-grid gap-2">
                        <a href="orcamentos.php?view=form" class="btn btn-outline-light text-start">📄 Novo Orçamento</a>
                        <a href="clientes.php?view=form&acao=novo" class="btn btn-outline-light text-start">👥 Cadastrar Cliente</a>
                        <a href="agenda.php" class="btn btn-outline-light text-start">📅 Ver Agenda Completa</a>
                        <a href="kanban.php" class="btn btn-outline-light text-start">🚀 Fluxo de Vendas</a>
                        <a href="contas_pagar.php" class="btn btn-outline-danger text-start">🔻 Contas a Pagar</a>
                        <a href="contas_receber.php" class="btn btn-outline-success text-start">💹 Contas a Receber</a>
                    </div>
                </div>
                
                <div class="card card-custom p-3 mt-3 border-secondary">
                    <small class="text-muted">Atividade Recente</small>
                    <div class="mt-2">
                        <div class="d-flex justify-content-between">
                            <span class="text-white">Vendas Hoje:</span> <span class="text-success fw-bold">
                                <?php 
                                    $vendas_hoje = $pdo->query("SELECT SUM(valor_total) FROM pedidos_orcamentos WHERE tipo='pedido' AND DATE(data_emissao) = '$hoje'")->fetchColumn();
                                    echo "R$ " . number_format($vendas_hoje ?: 0, 2, ',', '.');
                                ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>